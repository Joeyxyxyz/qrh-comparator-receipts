# Receipt: independent Comparator run of OpenAI's 7/8 zero-free half-plane

**Verdict: PASS**

Comparator accepted the proof.

Comparator's own closing lines: `Lean default kernel accepts the solution` and `Your solution is okay!`. This was a cold run: nothing of the proof had been compiled on this machine before Comparator compiled it in its sandbox.

## What was checked

- Theorem: `OAI.riemannZeta_ne_zero_of_seven_eighths_lt_re`
- Proof: module `OAI.NumberTheory.DirichletL.Nonvanishing` of https://github.com/openai/math at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`
- Proof size: 2,924 project files, 486,490 lines, plus 4 files of PrimeNumberTheoremAnd and 15 of rellich-kondrachov (with OpenAI's compatibility patches), on Mathlib `d13f23b723b8` and Lean v4.34.1
- Axioms allowed: `propext`, `Quot.sound`, `Classical.choice`
- Statement, as given to Comparator (the whole challenge file):

```lean
import Mathlib

namespace OAI

theorem riemannZeta_ne_zero_of_seven_eighths_lt_re
    {s : ℂ} (hs : (7 / 8 : ℝ) < s.re) : riemannZeta s ≠ 0 := by
  sorry

end OAI
```

## What a PASS means

1. The theorem the proof files prove is the statement above, with every definition it mentions identical on both sides.
2. The proof rests on no axiom other than the three listed.
3. Lean's kernel re-checked the exported proof term and everything it depends on, Mathlib's part included.

## What it does not mean

- It is not a check that the Lean statement matches the paper's English. The statement is a few lines; read it.
- It is not the Riemann Hypothesis. Zeros with 1/2 < Re s <= 7/8 are untouched by this theorem.
- It is one kernel (Lean's own). No second kernel was run.
- It trusts: Lean's kernel and the released Lean toolchain; Comparator and lean4export; Mathlib's definitions and its prebuilt cache; OpenAI's challenge file and lakefile (read when the kit was written, pinned by sha256); landrun, Landlock, systemd and the Linux kernel for the sandbox; this machine and whoever operated it.

## Attempts

| # | Kind | Started (UTC) | Ended (UTC) | Exit | Outcome |
|---|---|---|---|---|---|
| 1 | cold | 2026-10-27T17:43:45Z | 2026-10-27T19:38:23Z | 0 | ACCEPTED: Comparator accepted the proof |

## The run

| | |
|---|---|
| Wall clock | 1:54:37 |
| Run type | cold |
| Peak memory of the job (program memory plus swap, sampled each minute) | 5.6 GiB |
| Peak memory, largest single process | 7.0 GiB |
| Machine at launch | 8 CPUs, 37 GB RAM, 39 GB swap, kernel 7.0.0-38-generic, Landlock ABI 8 |
| Launch | systemd-user RestrictAddressFamilies=~AF_UNIX SystemCallArchitectures=native OOMPolicy=continue LimitSTACK=1G |
| Inside the run's own unit | AF_UNIX sockets denied; stack limit 1048576 kB |
| Sandbox enforcing / inside Comparator / AF_UNIX restricted / TCP in sandbox | yes / yes / yes / blocked |
| Controls | 6 accepted, 15 rejected (expected 6 and 15); 4 nanoda-only projects skipped |
| Lean | Lean (version 4.34.1, x86_64-unknown-linux-gnu, commit 5045d0056413266e57c625dcd7c365b10e377c52, Release); release files verified: yes (7 files match the pinned sha256 of the v4.34.1 release) |
| Comparator | v4.34.0 `d03acab154d269c06e60e4de7e4cc85deebff94b`, built with leanprover/lean4:v4.34.1 (upstream pins leanprover/lean4:v4.34.0) |
| lean4export | `076e8e57707e813375e8f9da8bf989799ace9680` |
| landrun | `811cfff51ceaf3d9843708aa6d22e9b84ccac8b4` (landrun version 0.1.18), static: yes |
| Mathlib | `d13f23b723b8a846827a245b89c10fc7d3f11612`, prebuilt cache (lake exe cache get); cache complete: yes |
| Compiled dependency files before the run | 106968 files, digest `a12ec201639976add458307f6cfd34fe9592474b706e6b1ea0a8378cc18ee93f` |
| After the run | OpenAI checkout verified: yes; trusted inputs: unchanged; proof sources: unchanged; checker binaries: unchanged; kit: unmodified |
| OpenAI repository head at fetch time | 7ef5c0cc5ca4b0e072b7a050fca09ab24bc6fa3a (NEWER than pinned) |

## Deviations from the scripted protocol

One deviation is built into the kit: Comparator and lean4export have no release for Lean 4.34.1, so their v4.34.0 sources were built with the 4.34.1 toolchain. Their own regression projects were run in that configuration as part of the controls.

No others recorded.

## Files

`receipt.json` (this receipt, machine-readable), `facts.tsv` (every recorded fact with its time), `closure.json` (the static scan of the proof's files), `packages.tsv` (every dependency and its commit), `deps_compiled.sha256` and `mathlib_sources.sha256` (what the run trusted, file by file), and the logs, including the exact job script `qrh-main.job.sh` and Comparator's full output `qrh-main.log`.
