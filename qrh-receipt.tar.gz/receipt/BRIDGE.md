# MNF bridge on top of the checked 7/8 theorem

**Result: BRIDGE-OK**

Both bridge files compiled with OpenAI's Lean toolchain against the tree Comparator checked. All 21 audited theorems depend on no axiom other than propext, Classical.choice, Quot.sound.

## Theorems that no longer carry the 7/8 hypothesis

As printed by Lean (`#check`):

```lean
MNF.Bridge78.zeroFree_seven_eighths : MNF.Bridge78.ZeroFreeRightOf (7 / 8)
MNF.Bridge78.nontrivial_zero_re_mem_unconditional {ρ : ℂ} (hρ : MNF.Bridge78.is_nontrivial_zero ρ) :
  1 / 8 ≤ ρ.re ∧ ρ.re ≤ 7 / 8
MNF.Bridge78.shifted_bounded_three_eighths_unconditional (x : ℝ) : x ∈ MNF.Bridge78.ShiftedZeroSpectrum → |x| ≤ 3 / 8
MNF.Bridge78.riemannHypothesis_iff_gap_unconditional {Δ : ℝ} (hΔ : 3 / 8 < Δ) :
  RiemannHypothesis ↔ MNF.Bridge78.SpectralGapProperty MNF.Bridge78.ShiftedZeroSpectrum Δ
MNF.Bridge78.riemannHypothesis_iff_remaining_strip_unconditional :
  RiemannHypothesis ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re ≤ 7 / 8 → riemannZeta s ≠ 0
MNF.Bridge78.zetaZeros_satisfies_structural_inputs_unconditional :
  MNF.Bridge78.StripSymmetric MNF.Bridge78.ZetaZeros ∧ ∀ ρ ∈ MNF.Bridge78.ZetaZeros, ρ.re ≤ 7 / 8
MNF.Bridge78.euler_type_no_go_unconditional :
  (∀ (s : ℂ), 7 / 8 < s.re → riemannZeta s * MNF.Bridge78.twoFactor s ≠ 0) ∧
    ∃ s, 1 / 2 < s.re ∧ s.re ≤ 7 / 8 ∧ riemannZeta s * MNF.Bridge78.twoFactor s = 0
```

These are, character for character, the statements recorded when the kit was written (`bridge/expected_statements.txt`).

## How to read this

- The Riemann Hypothesis is not among them. `riemannHypothesis_iff_remaining_strip_unconditional` states what is left: no zeros with 1/2 < Re s <= 7/8. Nothing here closes that strip.
- `riemannHypothesis_iff_gap_unconditional` lowers the threshold at which the MNF gap hypothesis is equivalent to RH from 1/2 to any value above 3/8. The gap hypothesis itself stays open.
- These statements rest on OpenAI's theorem, so they are exactly as reliable as the Comparator PASS in RECEIPT.md.
- This step is an ordinary Lean compile with `#print axioms`, run inside the sandbox; it is not a second Comparator run. The bridge's own proofs were also compiled when the kit was written (the second file against a stand-in for OpenAI's theorem).

## Axiom reports

| theorem | axioms |
|---|---|
| `MNF.Bridge78.tau_threshold` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.structural_inputs_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.structural_inputs_do_not_give_gap` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.analytic_no_go` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.nontrivial_zero_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.in_strip_of_nontrivial` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.nontrivial_zero_re_mem` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.shifted_bounded_three_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.riemannHypothesis_iff_gap` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.riemannHypothesis_iff_remaining_strip` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.euler_type_no_go` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.completed_twoFactor_symm` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.twoFactor_zero_re` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.euler_type_no_go_under_h78` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.zeroFree_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.nontrivial_zero_re_mem_unconditional` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.shifted_bounded_three_eighths_unconditional` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.riemannHypothesis_iff_gap_unconditional` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.riemannHypothesis_iff_remaining_strip_unconditional` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.zetaZeros_satisfies_structural_inputs_unconditional` | Classical.choice, Quot.sound, propext |
| `MNF.Bridge78.euler_type_no_go_unconditional` | Classical.choice, Quot.sound, propext |
