# MNF.RH library and the restatement of zeta23's Theorems A–D over MNF's definitions

**Result: MNF_ZETA23=ACCEPTED**

zeta23 receipt (`RECEIPT-zeta23.md`): **PASS**. The run below is a second, separate Comparator run on the same tree: its challenge (`MNFChallenges/*.lean`, every proof `sorry`, Mathlib only) states the MNF theorems and the definitions they use; its solution (`MNF.RH.Zeta23Restated`) proves them, delegating to zeta23's theorems where a proportion of zeros is asserted. Comparator built both in its sandbox, exported both, and checked that every theorem statement and every definition (name, type and body) agrees and that the proofs use no axiom beyond propext, Quot.sound, Classical.choice; Lean's kernel and NanoDa replayed the solution.

- Comparator job `zeta23-mnf`: exit 0, started 2026-10-29T02:06:38Z, ended 2026-10-29T02:12:34Z (warm with respect to the Zeta23 library, which the accepted zeta23-main run compiled; cold with respect to MNF/)
- launch: systemd-user RestrictAddressFamilies=~AF_UNIX SystemCallArchitectures=native OOMPolicy=continue LimitSTACK=1G; AF_UNIX sockets in the job: denied
- 62 theorems named in the challenge config; 23 definitions in the challenge, all compared by name, type and body (definition_names is empty)
- tree: the zeta23 checkout at `/home/qrh/qrh-zeta23-work/formal-math/zeta23` as checked by zeta23-main, plus `MNF/`, `MNFChallenges/`, `MNF_AuditB2.lean` and two `lean_lib` stanzas appended to `lakefile.toml`
- MNF files (sha256 listing): `6a77a635f4b4a782cc6b9e535bf398f72948fe41e6c329b8740aa8bfc058f06a`; lakefile.toml after the append: `b58855d79a113fb5cb39761d3a4d77fe4e5397ce319d775a20608a11a4f24eb1`

## What was proved

As printed by Lean (`#check`), from the audit compile:

```lean
MNF.RH.zeta_order_ge_one {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : 1 ≤ MNF.RH.zeta_order ρ
MNF.RH.order_one_iff_deriv {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.zeta_order ρ = 1 ↔ deriv riemannZeta ρ ≠ 0
MNF.RH.deriv_zero_of_high_order {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) (h2 : 2 ≤ MNF.RH.zeta_order ρ) :
  deriv riemannZeta ρ = 0
MNF.RH.allZerosSimple_iff_derivativeNonvanishing : MNF.RH.AllZerosSimple ↔ MNF.RH.DerivativeNonvanishing
MNF.RH.nontrivial_zero_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.is_nontrivial_zero (1 - ρ)
MNF.RH.deriv_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  deriv riemannZeta (1 - ρ) = -(MNF.RH.feFactor ρ * deriv riemannZeta ρ)
MNF.RH.deriv_ne_zero_reflect_iff {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  deriv riemannZeta (1 - ρ) ≠ 0 ↔ deriv riemannZeta ρ ≠ 0
MNF.RH.analyticOrderAt_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  analyticOrderAt riemannZeta (1 - ρ) = analyticOrderAt riemannZeta ρ
MNF.RH.zeta_order_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.zeta_order (1 - ρ) = MNF.RH.zeta_order ρ
MNF.RH.shifted_symmetric {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : -x ∈ MNF.RH.ShiftedZeroSpectrum
MNF.RH.in_strip_of_zero {s : ℂ} (hs : riemannZeta s = 0) (htriv : ¬∃ n, s = -2 * (↑n + 1)) (h1 : s ≠ 1) :
  0 < s.re ∧ s.re < 1
MNF.RH.riemannHypothesis_iff_strip : RiemannHypothesis ↔ ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2
MNF.RH.riemannHypothesis_iff_shifted_subset_zero : RiemannHypothesis ↔ MNF.RH.ShiftedZeroSpectrum ⊆ {0}
MNF.RH.shifted_bounded {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| < 1 / 2
MNF.RH.tau_threshold {S : Set ℝ} {Δ : ℝ} (hgap : MNF.RH.SpectralGapProperty S Δ) (hbound : ∀ x ∈ S, |x| < Δ) : S ⊆ {0}
MNF.RH.riemannHypothesis_iff_gap_half {Δ : ℝ} (hΔ : 1 / 2 ≤ Δ) :
  RiemannHypothesis ↔ MNF.RH.SpectralGapProperty MNF.RH.ShiftedZeroSpectrum Δ
MNF.RH.shifted_bounded_of_zeroFree {θ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) {x : ℝ}
  (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| ≤ θ - 1 / 2
MNF.RH.riemannHypothesis_iff_gap_of_zeroFree {θ Δ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) (hΔ : θ - 1 / 2 < Δ) :
  RiemannHypothesis ↔ MNF.RH.SpectralGapProperty MNF.RH.ShiftedZeroSpectrum Δ
MNF.RH.riemannHypothesis_iff_remaining_strip {θ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) :
  RiemannHypothesis ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re ≤ θ → riemannZeta s ≠ 0
MNF.RH.gap_below_bound_insufficient {b Δ : ℝ} (hΔ : 0 < Δ) (hb : Δ < b) :
  ∃ S ⊆ Set.Ioo (-b) b, (∀ x ∈ S, -x ∈ S) ∧ MNF.RH.SpectralGapProperty S Δ ∧ S ≠ {0}
MNF.RH.symmetric_bounded_not_on_line :
  ¬∀ (Z : Set ℂ), (∀ ρ ∈ Z, 1 - ρ ∈ Z) → (∀ ρ ∈ Z, ρ.re ≤ 7 / 8) → ∀ ρ ∈ Z, ρ.re = 1 / 2
MNF.RH.sign_gate_trivial {S : Set ℝ} (hS : ∀ x ∈ S, -x ∈ S) : MNF.RH.signGate S = {0}
MNF.RH.sign_gate_shifted : MNF.RH.signGate MNF.RH.ShiftedZeroSpectrum = {0}
MNF.RH.nullify_dilation {l : ℝ} (hl : 0 < l) (Δ x : ℝ) : MNF.RH.nullify (l * Δ) (l * x) = l * MNF.RH.nullify Δ x
MNF.RH.gap_iff_nullify_id (S : Set ℝ) (Δ : ℝ) : MNF.RH.SpectralGapProperty S Δ ↔ ∀ x ∈ S, MNF.RH.nullify Δ x = x
MNF.RH.delta_from_ratio_38_insufficient :
  1 / 2 * (3 / 8) = 3 / 16 ∧
    ∃ S ⊆ Set.Ioo (-(3 / 8)) (3 / 8), (∀ x ∈ S, -x ∈ S) ∧ MNF.RH.SpectralGapProperty S (3 / 16) ∧ S ≠ {0}
MNF.RH.rh_of_gap {Δ : ℝ} (hΔ : 1 / 2 ≤ Δ) (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.rh_of_gap_of_zeroFree {θ Δ : ℝ} (hθ : MNF.RH.ZeroFreeRightOf θ) (hΔ : θ - 1 / 2 < Δ)
  (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.gap_of_rh (h : RiemannHypothesis) (Δ : ℝ) : MNF.RH.SpectralGapHyp Δ
MNF.RH.spectralGapHyp_iff_zeroFree_strip {Δ : ℝ} :
  MNF.RH.SpectralGapHyp Δ ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re < 1 / 2 + Δ → riemannZeta s ≠ 0
MNF.RH.spectralGapHyp_three_eighths_iff_of (h : MNF.RH.ZeroFreeRightOf (7 / 8)) :
  MNF.RH.SpectralGapHyp (3 / 8) ↔ ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2 ∨ ρ.re = 1 / 8 ∨ ρ.re = 7 / 8
MNF.RH.multiplicityBoundOne_iff_allZerosSimple : MNF.RH.MultiplicityBoundOne ↔ MNF.RH.AllZerosSimple
MNF.RH.derivativeNonvanishing_of_left
  (h : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re ≤ 1 / 2 → deriv riemannZeta ρ ≠ 0) : MNF.RH.DerivativeNonvanishing
MNF.RH.allZerosSimple_of_speiser_and_double_zero_hyp (hRH : RiemannHypothesis) (hSp : MNF.RH.SpeiserTheorem)
  (hDZ : MNF.RH.DoubleZeroForcesLeftDerivZero) : MNF.RH.AllZerosSimple
MNF.RH.allZerosSimple_of_rh_of_line (hRH : RiemannHypothesis)
  (hline : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2 → deriv riemannZeta ρ ≠ 0) : MNF.RH.AllZerosSimple
MNF.RH.rh_of_symmetric_operator.{u_1} {E : Type u_1} [NormedAddCommGroup E] [InnerProductSpace ℂ E] (T : E →ₗ[ℂ] E)
  (hT : T.IsSymmetric)
  (hspec : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → Module.End.HasEigenvalue T ((ρ - 1 / 2) / Complex.I)) :
  RiemannHypothesis
MNF.RH.mem_zerosIn {T₁ T₂ : ℝ} {ρ : ℂ} : ρ ∈ MNF.RH.zerosIn T₁ T₂ ↔ MNF.RH.is_nontrivial_zero ρ ∧ T₁ < ρ.im ∧ ρ.im ≤ T₂
MNF.RH.zerosIn_subset_zetaZeros (T₁ T₂ : ℝ) : MNF.RH.zerosIn T₁ T₂ ⊆ MNF.RH.ZetaZeros
MNF.RH.zerosIn_mono {T₁ T₁' T₂ T₂' : ℝ} (h₁ : T₁' ≤ T₁) (h₂ : T₂ ≤ T₂') : MNF.RH.zerosIn T₁ T₂ ⊆ MNF.RH.zerosIn T₁' T₂'
MNF.RH.zerosIn_subset_box (T₁ T₂ : ℝ) : MNF.RH.zerosIn T₁ T₂ ⊆ Set.Icc 0 1 ×ℂ Set.Icc T₁ T₂ ∩ riemannZetaZeros
MNF.RH.zerosIn_finite (T₁ T₂ : ℝ) : (MNF.RH.zerosIn T₁ T₂).Finite
MNF.RH.Ncount_eq_sum {T₁ T₂ : ℝ} (hfin : (MNF.RH.zerosIn T₁ T₂).Finite) :
  MNF.RH.Ncount T₁ T₂ = ∑ ρ ∈ hfin.toFinset, MNF.RH.zeta_order ρ
MNF.RH.Ndist_eq_sum_ones {T₁ T₂ : ℝ} (hfin : (MNF.RH.zerosIn T₁ T₂).Finite) :
  MNF.RH.Ndist T₁ T₂ = ∑ _ρ ∈ hfin.toFinset, 1
MNF.RH.Ndist_le_Ncount (T₁ T₂ : ℝ) : MNF.RH.Ndist T₁ T₂ ≤ MNF.RH.Ncount T₁ T₂
MNF.RH.N0star_le_Ndist (T₁ T₂ : ℝ) : MNF.RH.N0star T₁ T₂ ≤ MNF.RH.Ndist T₁ T₂
MNF.RH.N0simple_le_N0star (T₁ T₂ : ℝ) : MNF.RH.N0simple T₁ T₂ ≤ MNF.RH.N0star T₁ T₂
MNF.RH.riemannHypothesis_iff_window_counts : RiemannHypothesis ↔ ∀ (T₁ T₂ : ℝ), MNF.RH.N0star T₁ T₂ = MNF.RH.Ndist T₁ T₂
MNF.RH.allZerosSimple_iff_window_counts :
  MNF.RH.AllZerosSimple ↔ ∀ (T₁ T₂ : ℝ), MNF.RH.Ncount T₁ T₂ = MNF.RH.Ndist T₁ T₂
MNF.RH.N0simple_eq_deriv_form (T₁ T₂ : ℝ) :
  MNF.RH.N0simple T₁ T₂ = (MNF.RH.zerosIn T₁ T₂ ∩ {ρ | ρ.re = 1 / 2} ∩ {ρ | deriv riemannZeta ρ ≠ 0}).ncard
MNF.RH.twoThirdsOnLine (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 / 3 - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.N0star T (2 * T))
MNF.RH.twoThirdsOnLine_cumulative (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 / 3 - ε) * ↑(MNF.RH.Ncount 0 T) ≤ ↑(MNF.RH.N0star 0 T)
MNF.RH.twoThirdsSimpleOnLine (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 / 3 - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.N0simple T (2 * T))
MNF.RH.twoThirdsSimpleOnLine_cumulative (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 / 3 - ε) * ↑(MNF.RH.Ncount 0 T) ≤ ↑(MNF.RH.N0simple 0 T)
MNF.RH.fiveSixthsDistinct (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (5 / 6 - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.Ndist T (2 * T))
MNF.RH.fiveSixthsDistinct_cumulative (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (5 / 6 - ε) * ↑(MNF.RH.Ncount 0 T) ≤ ↑(MNF.RH.Ndist 0 T)
MNF.RH.montgomeryTaylorOnLine (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 - 1 / MNF.RH.cMT - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.N0star T (2 * T))
MNF.RH.montgomeryTaylorSimpleOnLine (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 - 1 / MNF.RH.cMT - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.N0simple T (2 * T))
MNF.RH.montgomeryTaylorSimpleOnLine_cumulative (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (2 - 1 / MNF.RH.cMT - ε) * ↑(MNF.RH.Ncount 0 T) ≤ ↑(MNF.RH.N0simple 0 T)
MNF.RH.montgomeryTaylorDistinct (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (3 / 2 - MNF.RH.cMT⁻¹ / 2 - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.Ndist T (2 * T))
MNF.RH.montgomeryTaylorDistinct_cumulative (ε : ℝ) :
  ε > 0 → ∃ T₀, ∀ T ≥ T₀, (3 / 2 - MNF.RH.cMT⁻¹ / 2 - ε) * ↑(MNF.RH.Ncount 0 T) ≤ ↑(MNF.RH.Ndist 0 T)
MNF.RH.twoThirdsOnLineDerivNeZero (ε : ℝ) :
  ε > 0 →
    ∃ T₀,
      ∀ T ≥ T₀,
        (2 / 3 - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤
          ↑(MNF.RH.zerosIn T (2 * T) ∩ {ρ | ρ.re = 1 / 2} ∩ {ρ | deriv riemannZeta ρ ≠ 0}).ncard
MNF.RH.fiveSixthsDistinct_sandwich (ε : ℝ) :
  ε > 0 →
    ∃ T₀,
      ∀ T ≥ T₀,
        (5 / 6 - ε) * ↑(MNF.RH.Ncount T (2 * T)) ≤ ↑(MNF.RH.Ndist T (2 * T)) ∧
          ↑(MNF.RH.Ndist T (2 * T)) ≤ ↑(MNF.RH.Ncount T (2 * T))
```

## How to read this

- Everything in `MNF/RH/Core.lean`, `Gap.lean`, `Hypotheses.lean` and `Counting.lean` is proved from Mathlib alone (the first three are byte-identical to the MNF add-on v2's, ACCEPTED on OpenAI's tree the same day). `Counting.lean` is bookkeeping: zeta23's counting vocabulary over MNF's names, finiteness of the zeros in a window, and two restatements (RH ⟺ the on-line and the distinct counts agree on every window; all zeros simple ⟺ the total and the distinct counts agree on every window).
- The theorems of `MNF/RH/Zeta23Restated.lean` are zeta23's Theorems A–D stated over MNF's definitions; they hold by definitional unfolding and are exactly as reliable as the zeta23 receipt. They assert proportions of zeros in windows (T, 2T] and (0, T] for large T, counted with multiplicity on the left and as distinct points on the right.
- None of this discharges `SpectralGapHyp`, `AllZerosSimple`, `MultiplicityBoundOne` or `DerivativeNonvanishing`: a proportion of zeros, however large, is not a statement about every zero. Nothing here uses OpenAI's 7/8 theorem, and no sentence should put the two together as one result.

## Axiom reports

| theorem | axioms |
|---|---|
| `MNF.RH.zeta_order_ge_one` | Classical.choice, Quot.sound, propext |
| `MNF.RH.order_one_iff_deriv` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_zero_of_high_order` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_iff_derivativeNonvanishing` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nontrivial_zero_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_ne_zero_reflect_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.analyticOrderAt_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zeta_order_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_symmetric` | Classical.choice, Quot.sound, propext |
| `MNF.RH.in_strip_of_zero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_shifted_subset_zero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded` | Classical.choice, Quot.sound, propext |
| `MNF.RH.tau_threshold` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_half` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_remaining_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_below_bound_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.RH.symmetric_bounded_not_on_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.sign_gate_trivial` | Classical.choice, Quot.sound, propext |
| `MNF.RH.sign_gate_shifted` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nullify_dilation` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_iff_nullify_id` | Classical.choice, Quot.sound, propext |
| `MNF.RH.delta_from_ratio_38_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_of_rh` | Classical.choice, Quot.sound, propext |
| `MNF.RH.multiplicityBoundOne_iff_allZerosSimple` | Classical.choice, Quot.sound, propext |
| `MNF.RH.derivativeNonvanishing_of_left` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_speiser_and_double_zero_hyp` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_rh_of_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_symmetric_operator` | Classical.choice, Quot.sound, propext |
| `MNF.RH.spectralGapHyp_iff_zeroFree_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.spectralGapHyp_three_eighths_iff_of` | Classical.choice, Quot.sound, propext |
| `MNF.RH.mem_zerosIn` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_subset_zetaZeros` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_mono` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_subset_box` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_finite` | Classical.choice, Quot.sound, propext |
| `MNF.RH.Ncount_eq_sum` | Classical.choice, Quot.sound, propext |
| `MNF.RH.Ndist_eq_sum_ones` | Classical.choice, Quot.sound, propext |
| `MNF.RH.Ndist_le_Ncount` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0star_le_Ndist` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0simple_le_N0star` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_window_counts` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_iff_window_counts` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0simple_eq_deriv_form` | Classical.choice, Quot.sound, propext |
| `MNF.RH.twoThirdsOnLine` | Classical.choice, Quot.sound, propext |
| `MNF.RH.twoThirdsOnLine_cumulative` | Classical.choice, Quot.sound, propext |
| `MNF.RH.twoThirdsSimpleOnLine` | Classical.choice, Quot.sound, propext |
| `MNF.RH.twoThirdsSimpleOnLine_cumulative` | Classical.choice, Quot.sound, propext |
| `MNF.RH.fiveSixthsDistinct` | Classical.choice, Quot.sound, propext |
| `MNF.RH.fiveSixthsDistinct_cumulative` | Classical.choice, Quot.sound, propext |
| `MNF.RH.montgomeryTaylorOnLine` | Classical.choice, Quot.sound, propext |
| `MNF.RH.montgomeryTaylorSimpleOnLine` | Classical.choice, Quot.sound, propext |
| `MNF.RH.montgomeryTaylorSimpleOnLine_cumulative` | Classical.choice, Quot.sound, propext |
| `MNF.RH.montgomeryTaylorDistinct` | Classical.choice, Quot.sound, propext |
| `MNF.RH.montgomeryTaylorDistinct_cumulative` | Classical.choice, Quot.sound, propext |
| `MNF.RH.twoThirdsOnLineDerivNeZero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.fiveSixthsDistinct_sandwich` | Classical.choice, Quot.sound, propext |

## Hashes

```
c768a8b2b1b8cfeea30f7e4f532e490030c611ff3017b23aea919c11a04c8f25  MNF/RH/Core.lean
9419bf81bfddaafe641f0587998d98aade8a663b64f65cdef3bb97466840d343  MNF/RH/Counting.lean
5a008cd5d18eaed26eea66e236cbe5f0f3c7d0bd64a1d449e3232edf78494a71  MNF/RH/Gap.lean
5b3c90e3b39a95fab27cd99b06fed06ea1a61de51cb7b1fa9c836e4d56ec2026  MNF/RH/Hypotheses.lean
441912f9657657606c323c609e533471526a95fe71a2372fbbc1ef586c9258aa  MNF/RH/Zeta23Restated.lean
40f992bf755331d300cc52c8a1b3733a84ba9313e7dc55cc69884d49f55091c5  MNFChallenges/Core.lean
20355b646240197558feb9a1deecb214e43aa89dba127635b81e1529128ba582  MNFChallenges/Counting.lean
c54f989f7320cbe55d047572b85378e628c1407020463c608fcf84d43b977657  MNFChallenges/Gap.lean
faf51146d771dd44e3860e25040b7f59fe4537c78d5ac659418d7d5ad588340c  MNFChallenges/Hypotheses.lean
ee57e18c82cffe52f7624c0d11e81ce0a5797e4bc32b43825aab39a40663e34a  MNFChallenges/Restated.lean
836cc388a747cecd5db6a0dbb090bce6f5e2c4faa86240d7f092f86102cf1482  MNFChallenges/Restated.json
3a7fdd9717e024952452751f7d7fe0770b8fdb947a5b0b59fa76d5686991f8e5  MNFChallenges/theorem_list.txt
301b02610592f7b4fce524d1efedf45b2177931e2ae3ea98e5b076af55f19544  MNF_AuditB2.lean
b58855d79a113fb5cb39761d3a4d77fe4e5397ce319d775a20608a11a4f24eb1  lakefile.toml
```

## Last lines of Comparator's log

```
info: MNF/RH/Zeta23Restated.lean:187:0: 'MNF.RH.montgomeryTaylorSimpleOnLine_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Zeta23Restated.lean:188:0: 'MNF.RH.montgomeryTaylorDistinct' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Zeta23Restated.lean:189:0: 'MNF.RH.montgomeryTaylorDistinct_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Zeta23Restated.lean:190:0: 'MNF.RH.twoThirdsOnLineDerivNeZero' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Zeta23Restated.lean:191:0: 'MNF.RH.fiveSixthsDistinct_sandwich' depends on axioms: [propext, Classical.choice, Quot.sound]
Build completed successfully (8891 jobs).
Exporting #[Nat, String, String.mk, Char, Quot, Quot.mk, Quot.lift, Quot.ind, MNF.RH.zeta_order_ge_one, MNF.RH.order_one_iff_deriv, MNF.RH.deriv_zero_of_high_order, MNF.RH.allZerosSimple_iff_derivativ
Running nanoda kernel on solution
Nanoda kernel accepts the solution
Running Lean default kernel on solution.
Lean default kernel accepts the solution
Your solution is okay!
```
