# MNF.RH library on top of the checked 7/8 theorem

**Result: MNF_LIBRARY=ACCEPTED**

Main kit verdict for `OAI.riemannZeta_ne_zero_of_seven_eighths_lt_re`: **PASS** (RECEIPT.md). The library run below is a second, separate Comparator run: its challenge (`MNFChallenges/RH.lean`, every proof `sorry`) states the MNF theorems and the definitions they use; its solution (`MNF.RH.Unconditional`) proves them, using OpenAI's theorem where the 7/8 region is needed. Comparator built both in its sandbox, exported both, and checked that every definition and statement agrees and that the proofs use no axiom beyond propext, Quot.sound, Classical.choice.

- Comparator job `mnf-library`: exit 0, started 2026-10-28T00:20:02Z, ended 2026-10-28T00:32:46Z
- launch: systemd-user RestrictAddressFamilies=~AF_UNIX SystemCallArchitectures=native OOMPolicy=continue LimitSTACK=1G; AF_UNIX sockets in the job: denied
- 40 theorems, 17 definitions named in the challenge config
- tree: a copy of the verified tree at `/home/qrh/qrh-work/mnf-tree`, plus `MNF/`, `MNFChallenges/`, `MNF_Audit.lean` and two `lean_lib` lines appended to `lakefile.lean`

## What was proved

As printed by Lean (`#check`), from the audit compile:

```lean
MNF.RH.zeta_order_ge_one {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : 1 ≤ MNF.RH.zeta_order ρ
MNF.RH.order_one_iff_deriv {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.zeta_order ρ = 1 ↔ deriv riemannZeta ρ ≠ 0
MNF.RH.deriv_zero_of_high_order {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) (h2 : 2 ≤ MNF.RH.zeta_order ρ) :
  deriv riemannZeta ρ = 0
MNF.RH.allZerosSimple_iff_derivativeNonvanishing : MNF.RH.AllZerosSimple ↔ MNF.RH.DerivativeNonvanishing
MNF.RH.nontrivial_zero_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.is_nontrivial_zero (1 - ρ)
MNF.RH.deriv_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  deriv riemannZeta (1 - ρ) = -(MNF.RH.feFactor ρ * deriv riemannZeta ρ)
MNF.RH.deriv_ne_zero_reflect_iff {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  deriv riemannZeta (1 - ρ) ≠ 0 ↔ deriv riemannZeta ρ ≠ 0
MNF.RH.analyticOrderAt_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  analyticOrderAt riemannZeta (1 - ρ) = analyticOrderAt riemannZeta ρ
MNF.RH.zeta_order_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.zeta_order (1 - ρ) = MNF.RH.zeta_order ρ
MNF.RH.shifted_symmetric {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : -x ∈ MNF.RH.ShiftedZeroSpectrum
MNF.RH.in_strip_of_zero {s : ℂ} (hs : riemannZeta s = 0) (htriv : ¬∃ n, s = -2 * (↑n + 1)) (h1 : s ≠ 1) :
  0 < s.re ∧ s.re < 1
MNF.RH.riemannHypothesis_iff_strip : RiemannHypothesis ↔ ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2
MNF.RH.riemannHypothesis_iff_shifted_subset_zero : RiemannHypothesis ↔ MNF.RH.ShiftedZeroSpectrum ⊆ {0}
MNF.RH.shifted_bounded {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| < 1 / 2
MNF.RH.tau_threshold {S : Set ℝ} {Δ : ℝ} (hgap : MNF.RH.SpectralGapProperty S Δ) (hbound : ∀ x ∈ S, |x| < Δ) : S ⊆ {0}
MNF.RH.riemannHypothesis_iff_gap_half {Δ : ℝ} (hΔ : 1 / 2 ≤ Δ) :
  RiemannHypothesis ↔ MNF.RH.SpectralGapProperty MNF.RH.ShiftedZeroSpectrum Δ
MNF.RH.shifted_bounded_of_zeroFree {θ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) {x : ℝ}
  (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| ≤ θ - 1 / 2
MNF.RH.riemannHypothesis_iff_gap_of_zeroFree {θ Δ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) (hΔ : θ - 1 / 2 < Δ) :
  RiemannHypothesis ↔ MNF.RH.SpectralGapProperty MNF.RH.ShiftedZeroSpectrum Δ
MNF.RH.riemannHypothesis_iff_remaining_strip {θ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) :
  RiemannHypothesis ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re ≤ θ → riemannZeta s ≠ 0
MNF.RH.gap_below_bound_insufficient {b Δ : ℝ} (hΔ : 0 < Δ) (hb : Δ < b) :
  ∃ S ⊆ Set.Ioo (-b) b, (∀ x ∈ S, -x ∈ S) ∧ MNF.RH.SpectralGapProperty S Δ ∧ S ≠ {0}
MNF.RH.symmetric_bounded_not_on_line :
  ¬∀ (Z : Set ℂ), (∀ ρ ∈ Z, 1 - ρ ∈ Z) → (∀ ρ ∈ Z, ρ.re ≤ 7 / 8) → ∀ ρ ∈ Z, ρ.re = 1 / 2
MNF.RH.sign_gate_trivial {S : Set ℝ} (hS : ∀ x ∈ S, -x ∈ S) : MNF.RH.signGate S = {0}
MNF.RH.sign_gate_shifted : MNF.RH.signGate MNF.RH.ShiftedZeroSpectrum = {0}
MNF.RH.nullify_dilation {l : ℝ} (hl : 0 < l) (Δ x : ℝ) : MNF.RH.nullify (l * Δ) (l * x) = l * MNF.RH.nullify Δ x
MNF.RH.gap_iff_nullify_id (S : Set ℝ) (Δ : ℝ) : MNF.RH.SpectralGapProperty S Δ ↔ ∀ x ∈ S, MNF.RH.nullify Δ x = x
MNF.RH.delta_from_ratio_38_insufficient :
  1 / 2 * (3 / 8) = 3 / 16 ∧
    ∃ S ⊆ Set.Ioo (-(3 / 8)) (3 / 8), (∀ x ∈ S, -x ∈ S) ∧ MNF.RH.SpectralGapProperty S (3 / 16) ∧ S ≠ {0}
MNF.RH.rh_of_gap {Δ : ℝ} (hΔ : 1 / 2 ≤ Δ) (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.rh_of_gap_of_zeroFree {θ Δ : ℝ} (hθ : MNF.RH.ZeroFreeRightOf θ) (hΔ : θ - 1 / 2 < Δ)
  (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.gap_of_rh (h : RiemannHypothesis) (Δ : ℝ) : MNF.RH.SpectralGapHyp Δ
MNF.RH.multiplicityBoundOne_iff_allZerosSimple : MNF.RH.MultiplicityBoundOne ↔ MNF.RH.AllZerosSimple
MNF.RH.derivativeNonvanishing_of_left
  (h : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re ≤ 1 / 2 → deriv riemannZeta ρ ≠ 0) : MNF.RH.DerivativeNonvanishing
MNF.RH.allZerosSimple_of_speiser_and_double_zero_hyp (hRH : RiemannHypothesis) (hSp : MNF.RH.SpeiserTheorem)
  (hDZ : MNF.RH.DoubleZeroForcesLeftDerivZero) : MNF.RH.AllZerosSimple
MNF.RH.allZerosSimple_of_rh_of_line (hRH : RiemannHypothesis)
  (hline : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2 → deriv riemannZeta ρ ≠ 0) : MNF.RH.AllZerosSimple
MNF.RH.rh_of_symmetric_operator.{u_1} {E : Type u_1} [NormedAddCommGroup E] [InnerProductSpace ℂ E] (T : E →ₗ[ℂ] E)
  (hT : T.IsSymmetric)
  (hspec : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → Module.End.HasEigenvalue T ((ρ - 1 / 2) / Complex.I)) :
  RiemannHypothesis
MNF.RH.zeroFree_seven_eighths : MNF.RH.ZeroFreeRightOf (7 / 8)
MNF.RH.nontrivial_zero_re_le_seven_eighths {ρ : ℂ} (hρ : MNF.RH.is_nontrivial_zero ρ) : ρ.re ≤ 7 / 8
MNF.RH.shifted_bounded_three_eighths {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| ≤ 3 / 8
MNF.RH.riemannHypothesis_iff_gap_three_eighths {Δ : ℝ} (hΔ : 3 / 8 < Δ) : RiemannHypothesis ↔ MNF.RH.SpectralGapHyp Δ
MNF.RH.riemannHypothesis_iff_remaining_strip_seven_eighths :
  RiemannHypothesis ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re ≤ 7 / 8 → riemannZeta s ≠ 0
MNF.RH.rh_of_gap_three_eighths {Δ : ℝ} (hΔ : 3 / 8 < Δ) (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
```

## How to read this

- Everything in `MNF/RH/Core.lean`, `Gap.lean` and `Hypotheses.lean` is proved from Mathlib alone; the theorems whose names end in `_seven_eighths` / `_three_eighths` (`Unconditional.lean`) use OpenAI's theorem and are exactly as reliable as the main kit's PASS.
- The Riemann Hypothesis is not among the theorems. `riemannHypothesis_iff_gap_three_eighths` says the MNF gap hypothesis at any Δ > 3/8 *is* RH; `gap_below_bound_insufficient` says a gap at Δ ≤ 3/8 cannot give it. `riemannHypothesis_iff_remaining_strip_seven_eighths` says what is left: no zeros with 1/2 < Re s ≤ 7/8.
- `SpeiserTheorem` and `DoubleZeroForcesLeftDerivZero` are hypotheses (explicit arguments), not axioms; nothing here asserts them.

## Axiom reports

| theorem | axioms |
|---|---|
| `MNF.RH.zeta_order_ge_one` | Classical.choice, Quot.sound, propext |
| `MNF.RH.order_one_iff_deriv` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_zero_of_high_order` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_iff_derivativeNonvanishing` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nontrivial_zero_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_ne_zero_reflect_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.analyticOrderAt_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zeta_order_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_symmetric` | Classical.choice, Quot.sound, propext |
| `MNF.RH.in_strip_of_zero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_shifted_subset_zero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded` | Classical.choice, Quot.sound, propext |
| `MNF.RH.tau_threshold` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_half` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_remaining_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_below_bound_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.RH.symmetric_bounded_not_on_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.sign_gate_trivial` | Classical.choice, Quot.sound, propext |
| `MNF.RH.sign_gate_shifted` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nullify_dilation` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_iff_nullify_id` | Classical.choice, Quot.sound, propext |
| `MNF.RH.delta_from_ratio_38_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_of_rh` | Classical.choice, Quot.sound, propext |
| `MNF.RH.multiplicityBoundOne_iff_allZerosSimple` | Classical.choice, Quot.sound, propext |
| `MNF.RH.derivativeNonvanishing_of_left` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_speiser_and_double_zero_hyp` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_rh_of_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_symmetric_operator` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zeroFree_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nontrivial_zero_re_le_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded_three_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_three_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_remaining_strip_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap_three_eighths` | Classical.choice, Quot.sound, propext |

## Hashes

```
c768a8b2b1b8cfeea30f7e4f532e490030c611ff3017b23aea919c11a04c8f25  MNF/RH/Core.lean
5a008cd5d18eaed26eea66e236cbe5f0f3c7d0bd64a1d449e3232edf78494a71  MNF/RH/Gap.lean
c4c21dafc98a361a2f6bf5b47ad4f513f7d7e8fe16d1d15a8011cdc5a1e225e1  MNF/RH/Hypotheses.lean
41f637ed2b2d772a7e2029959b5f0d41fc106f2214bb001bddb246585bbcc8a1  MNF/RH/Unconditional.lean
aa2ec72914b1af63a3e9fc8555f3cb07707e488e238cd9d2729d32653d04da21  MNFChallenges/RH.lean
7b7c11494d2abb523250aea0ac727386674c56c00dca9c229e3278f160f3f02b  MNFChallenges/RH.json
31182c91f19ecc98c4e7a4c88efcb2510ad1680209e04b5d764d4314328dc340  MNF_Audit.lean
c6a1c56738b0262b01e6b496d10325960b6e9a183c67ed4242e4bf33f289a390  lakefile_append.lean
lakefile.lean after the append: 4c9e5551480166cab734284e852c84711d3684eeb8104fcec233567a9e4d5a43
```

## Last lines of Comparator's log

```
info: MNF/RH/Hypotheses.lean:145:0: 'MNF.RH.allZerosSimple_of_rh_of_line' depends on axioms: [propext, Classical.choice, Quot.sound]
ℹ [7065/7065] Built MNF.RH.Unconditional (5.8s)
info: MNF/RH/Unconditional.lean:52:0: 'MNF.RH.zeroFree_seven_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:53:0: 'MNF.RH.shifted_bounded_three_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:54:0: 'MNF.RH.riemannHypothesis_iff_gap_three_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:55:0: 'MNF.RH.riemannHypothesis_iff_remaining_strip_seven_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:56:0: 'MNF.RH.rh_of_gap_three_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
Build completed successfully (7065 jobs).
Exporting #[Quot, Quot.mk, Quot.lift, Quot.ind, MNF.RH.zeta_order_ge_one, MNF.RH.order_one_iff_deriv, MNF.RH.deriv_zero_of_high_order, MNF.RH.allZerosSimple_iff_derivativeNonvanishing, MNF.RH.nontrivi
Running Lean default kernel on solution.
Lean default kernel accepts the solution
Your solution is okay!
```
