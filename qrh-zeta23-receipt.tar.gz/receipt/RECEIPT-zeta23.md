# Receipt: independent Comparator run of Anthropic's zeta23 formalization

**Verdict: PASS**

Comparator accepted the proof. Its own closing line: `Your solution is okay!`. This was a cold run: nothing of the challenge, the solution or the Zeta23 library had been compiled on this machine before Comparator compiled it in its sandbox. Kernels that replayed the proof: Lean's kernel and NanoDa.

## What was checked

- Project: `zeta23/` of https://github.com/anthropics/formal-math at commit `16a5ce41304fcdaea4e0be7c132e1c361dc26da5` (Alpöge–Furman, arXiv:2608.13637, formalized by Anthropic)
- Statements: the 17 theorems named in `comparator.json` (sha256 `610d95c6c84f13b3e2238b476fe45f0b28567108f536f67a0b9ed1586a2c68f1`), stated in `Challenge.lean` (sha256 `6f2a4ba95ab8c5319e541a1cc1b3699c0ae8cef23ea8e68f958e11b07281761e`), which imports only Mathlib and inlines the definitions of `ChallengeDeps.lean` (sha256 `8f9a7e7bb313bbada77d0dd1b71a80bda1c0580b71ba1dd0020b438d63a318e0`)
- Proof: module `Solution` and the `Zeta23` library it imports: 316 files, 102265 lines, on Mathlib `51e6992efd06` and leanprover/lean4:v4.33.0-rc2
- Configuration given to Comparator: `comparator.json` (sha256 `610d95c6c84f13b3e2238b476fe45f0b28567108f536f67a0b9ed1586a2c68f1`); kernels: Lean's kernel and NanoDa
- Axioms allowed: `propext`, `Quot.sound`, `Classical.choice`; no definition holes
- Checker: Comparator `v4.33.0-rc2` (75c730e9b6ef), lean4export 9fb131bb100e, landrun 811cfff51cea, nanoda 68d5ca9db226; Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release); toolchain binaries: yes (7 files match the pinned sha256 of the v4.33.0-rc2 release)
- Launch: systemd-user RestrictAddressFamilies=~AF_UNIX SystemCallArchitectures=native OOMPolicy=continue LimitSTACK=1G; AF_UNIX sockets in the job: denied; sandbox enforcing: yes; outbound TCP in the sandbox: blocked
- Run: cold, started 2026-10-28T11:08:56Z, ended 2026-10-28T11:29:58Z, exit 0, wall clock 21:01.50, largest process 6.9 GiB; machine: 8 CPUs, 37 GB RAM, 39 GB swap

## The theorem names

- `two_thirds_on_critical_line`
- `two_thirds_on_critical_line_cumulative`
- `two_thirds_simple_on_critical_line`
- `two_thirds_simple_on_critical_line_cumulative`
- `five_sixths_distinct`
- `five_sixths_distinct_cumulative`
- `montgomery_taylor_on_critical_line`
- `montgomery_taylor_simple_on_critical_line_mult`
- `montgomery_taylor_simple_on_critical_line_mult_cumulative`
- `montgomery_taylor_distinct_mult`
- `montgomery_taylor_distinct_mult_cumulative`
- `dirichlet_two_thirds_on_critical_line`
- `dirichlet_two_thirds_simple_on_critical_line`
- `dirichlet_five_sixths_distinct`
- `dirichlet_montgomery_taylor_on_critical_line`
- `dirichlet_montgomery_taylor_simple_on_critical_line_mult`
- `dirichlet_montgomery_taylor_distinct_mult`

## The statements, as given to Comparator (the whole of `Challenge.lean`)

```lean
/-
Copyright (c) 2026 Anthropic, PBC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
SPDX-License-Identifier: Apache-2.0
-/
/-
Challenge.lean — the TRUSTED comparator challenge module: WHAT IS CLAIMED.

Seventeen theorem statements about the zeros of Mathlib's `riemannZeta` and of Mathlib's
`DirichletCharacter.LFunction`, each with proof `sorry`: the ε-forms of the headline assertions of
Theorems A–E of the paper "More than two thirds of the zeros of the Riemann zeta function are simple and on the critical line", each at the constant stated in the paper. Writing N(T₁,T₂)
for the number of nontrivial zeros with T₁ < Im ρ ≤ T₂ counted with multiplicity, N₀* / N₀ˢ / N_d
for the distinct on-line / simple on-line / distinct counts (all defined from Mathlib alone in
ChallengeDeps.lean, inlined below), and "liminf_{T→∞} X(T)/N(T) ≥ c" as
"∀ ε > 0, ∃ T₀, ∀ T ≥ T₀, (c − ε)·N(T) ≤ X(T)":
  * Theorem A: N₀*/N ≥ 2/3 (dyadic windows (T,2T] and cumulative windows (0,T]);
  * Theorem B: N₀ˢ/N ≥ 2/3 (both forms);   * Theorem C: N_d/N ≥ 5/6 (both forms);
  * Theorem D: with the Montgomery–Taylor constant c₁* = `cMT` (§3 below), on dyadic windows
    N₀*/N ≥ 2 − 1/c₁*, and — dyadic and cumulative — N₀ˢ/N ≥ 2 − 1/c₁* and N_d/N ≥ (3 − 1/c₁*)/2;
  * Theorem E: for every primitive Dirichlet character χ mod q > 1, the analogues of A, B, C (dyadic)
    for the zeros of L(s,χ), and ("Theorem D holds likewise") the three Theorem-D bounds for L(s,χ).
Solution.lean (untrusted) proves exactly these statements by delegating to the Zeta23 library;
github.com/leanprover/comparator checks statement equality, that only the axioms propext,
Classical.choice, Quot.sound are used, and replays the proofs through the kernel. See README.md here.

The `sorry`s below are deliberate (this is the challenge side); expect "declaration uses 'sorry'"
warnings when building this module.
-/
import Mathlib

/-
The definitions below are inlined character-for-character from ChallengeDeps.lean
(the trusted Mathlib-only definition layer, which continues to exist for the Solution build), so
that this module's ONLY import is Mathlib. The anonymous `section` scopes ChallengeDeps.lean's
`open`s to the inlined definitions, leaving the elaboration context of the statements below exactly
as it was when this module imported the definition layer. The comparator identifies constants by
name and requires each definition to elaborate identically to its Solution-side namesake. The block
is the COMPLETE definition layer, not just the constants these statements mention: elaborating the
layer as a whole is what keeps the auxiliary lemmas it generates (e.g. N0star._proof_1, which later
definitions reuse) named identically on the challenge and solution sides.
-/
section
open scoped BigOperators ComplexConjugate
open Complex Set

noncomputable section

/-! ## 1. Nontrivial zeros of ζ and the counting functions (Theorems A–D) -/

/-- ρ is a nontrivial zero of the Riemann zeta function: ζ(ρ) = 0 with 0 < Re ρ < 1 (the open
critical strip). Every zero in the strip is "nontrivial" in the usual sense (it is neither a trivial
zero −2(n+1), of real part ≤ −2, nor the pole s = 1); the converse — that every zero other than the
trivial ones lies in the open strip — is classical and is not needed to state the theorems. -/
def IsNontrivialZero (ρ : ℂ) : Prop := riemannZeta ρ = 0 ∧ 0 < ρ.re ∧ ρ.re < 1

/-- m_ρ, the multiplicity of ρ: the order of vanishing of ζ at ρ, via Mathlib's `analyticOrderAt`
(ℕ∞-valued; `toNat` sends ⊤ to 0, so `1 ≤ zeroMult ρ` encodes both "ζ is not locally identically
zero at ρ" and "ρ is a zero"). -/
def zeroMult (ρ : ℂ) : ℕ := (analyticOrderAt riemannZeta ρ).toNat

/-- The nontrivial zeros with ordinate in the window (T₁, T₂]: {ρ | ζ(ρ) = 0, 0 < Re ρ < 1,
T₁ < Im ρ ≤ T₂}. (Positive-ordinate window, not |Im ρ|.) -/
def zerosIn (T₁ T₂ : ℝ) : Set ℂ := {ρ | IsNontrivialZero ρ ∧ T₁ < ρ.im ∧ ρ.im ≤ T₂}

/-- N(T₁,T₂): the number of nontrivial zeros with T₁ < Im ρ ≤ T₂, counted WITH multiplicity
(`∑ᶠ` is Mathlib's finite sum; that the window contains finitely many zeros is proved on the
solution side, not assumed). -/
def Ncount (T₁ T₂ : ℝ) : ℕ := ∑ᶠ ρ ∈ zerosIn T₁ T₂, zeroMult ρ

/-- N_d(T₁,T₂): the number of nontrivial zeros with T₁ < Im ρ ≤ T₂, each distinct zero counted
once. -/
def Ndist (T₁ T₂ : ℝ) : ℕ := (zerosIn T₁ T₂).ncard

/-- N₀*(T₁,T₂): the number of DISTINCT zeros ON the critical line Re ρ = 1/2 with
T₁ < Im ρ ≤ T₂. This is what Theorems A and D bound from below. -/
def N0star (T₁ T₂ : ℝ) : ℕ := (zerosIn T₁ T₂ ∩ {ρ | ρ.re = 1 / 2}).ncard

/-- N₀ˢ(T₁,T₂): the number of SIMPLE zeros (multiplicity exactly 1) ON the critical line with
T₁ < Im ρ ≤ T₂. -/
def N0simple (T₁ T₂ : ℝ) : ℕ := (zerosIn T₁ T₂ ∩ {ρ | ρ.re = 1 / 2} ∩ {ρ | zeroMult ρ = 1}).ncard

/-! ## 2. The same for a Dirichlet L-function L(s,χ) (Theorem E)

`χ.LFunction` is Mathlib's `DirichletCharacter.LFunction χ : ℂ → ℂ`, the analytic continuation of
L(s,χ) (for a character χ mod q, `q ≠ 0`). -/

section Dirichlet

variable {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q)

/-- ρ is a nontrivial zero of L(s,χ): L(ρ,χ) = 0 with 0 < Re ρ < 1. -/
def IsNontrivialZeroL (ρ : ℂ) : Prop := χ.LFunction ρ = 0 ∧ 0 < ρ.re ∧ ρ.re < 1

/-- m_ρ: the order of vanishing of L(·,χ) at ρ (via `analyticOrderAt`, as for ζ). -/
def zeroMultL (ρ : ℂ) : ℕ := (analyticOrderAt χ.LFunction ρ).toNat

/-- the nontrivial zeros of L(·,χ) with T₁ < Im ρ ≤ T₂. -/
def zerosInL (T₁ T₂ : ℝ) : Set ℂ := {ρ | IsNontrivialZeroL χ ρ ∧ T₁ < ρ.im ∧ ρ.im ≤ T₂}

/-- N_χ(T₁,T₂): nontrivial zeros of L(s,χ) with T₁ < Im ρ ≤ T₂, with multiplicity. -/
def NcountL (T₁ T₂ : ℝ) : ℕ := ∑ᶠ ρ ∈ zerosInL χ T₁ T₂, zeroMultL χ ρ
/-- N_{d,χ}(T₁,T₂): distinct zeros. -/
def NdistL (T₁ T₂ : ℝ) : ℕ := (zerosInL χ T₁ T₂).ncard
/-- N*_{0,χ}(T₁,T₂): on the line, distinct. -/
def N0starL (T₁ T₂ : ℝ) : ℕ := (zerosInL χ T₁ T₂ ∩ {ρ | ρ.re = 1 / 2}).ncard
/-- N^s_{0,χ}(T₁,T₂): on the line and simple. -/
def N0simpleL (T₁ T₂ : ℝ) : ℕ :=
  (zerosInL χ T₁ T₂ ∩ {ρ | ρ.re = 1 / 2} ∩ {ρ | zeroMultL χ ρ = 1}).ncard

end Dirichlet

/-! ## 3. The Montgomery–Taylor constant of Theorem D -/

/-- c₁* := √2·tan ϑ / (1 + ϑ·tan ϑ) at ϑ = 1/√2 — the paper's closed form for the optimal-window
constant c*_λ = √2·tan ϑ/(1 + ϑ·tan ϑ), ϑ = λ/√2, at λ = 1. Numerically c₁* = 0.7532960…
(= 2·tan(1/√2)/(√2 + tan(1/√2)); 1/c₁* = 1/2 + 2^{-1/2}·cot(2^{-1/2}) is the Montgomery–Taylor
constant). Theorem D's proportions here are 2 − 1/c₁* = 0.67250… (for N₀* and N₀ˢ) and
(3 − 1/c₁*)/2 = 0.83625… (for N_d); the decimals are NOT part of the formal statements. -/
def cMT : ℝ :=
  Real.sqrt 2 * Real.tan (1 / Real.sqrt 2) / (1 + 1 / Real.sqrt 2 * Real.tan (1 / Real.sqrt 2))

end
end

noncomputable section

/-- **Theorem A — at least 2/3 of the nontrivial zeros of ζ lie on the critical line** (dyadic
windows): for every ε > 0 and all sufficiently large T, (2/3 − ε)·N(T,2T) ≤ N₀*(T,2T), i.e.
liminf_{T→∞} N₀*(T,2T)/N(T,2T) ≥ 2/3. The zeros with T < Im ρ ≤ 2T are counted WITH multiplicity on
the left and as DISTINCT points of the critical line on the right. -/
theorem two_thirds_on_critical_line :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 / 3 - ε) * (Ncount T (2 * T) : ℝ) ≤ N0star T (2 * T) := by
  sorry

/-- **Theorem A**, cumulative form: liminf_{T→∞} N₀*(T)/N(T) ≥ 2/3 (windows (0,T]). -/
theorem two_thirds_on_critical_line_cumulative :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 / 3 - ε) * (Ncount 0 T : ℝ) ≤ N0star 0 T := by
  sorry

/-- **Theorem B**: at least 2/3 of the nontrivial zeros of ζ are *simple and* on the critical
line (dyadic windows). -/
theorem two_thirds_simple_on_critical_line :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 / 3 - ε) * (Ncount T (2 * T) : ℝ) ≤ N0simple T (2 * T) := by
  sorry

/-- cumulative form: liminf_{T→∞} N₀ˢ(T)/N(T) ≥ 2/3. -/
theorem two_thirds_simple_on_critical_line_cumulative :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 / 3 - ε) * (Ncount 0 T : ℝ) ≤ N0simple 0 T := by
  sorry

/-- **Theorem C**: at least 5/6 of the nontrivial zeros of ζ are distinct (dyadic windows). -/
theorem five_sixths_distinct :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (5 / 6 - ε) * (Ncount T (2 * T) : ℝ) ≤ Ndist T (2 * T) := by
  sorry

/-- cumulative form: liminf_{T→∞} N_d(T)/N(T) ≥ 5/6. -/
theorem five_sixths_distinct_cumulative :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (5 / 6 - ε) * (Ncount 0 T : ℝ) ≤ Ndist 0 T := by
  sorry

/-- **Theorem D — the optimal (Montgomery–Taylor) window**: liminf_{T→∞} N₀*(T,2T)/N(T,2T) ≥ 2 −
1/c₁* (= 3/2 − cot(1/√2)/√2 = 0.67250…), with c₁* = `cMT`. -/
theorem montgomery_taylor_on_critical_line :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 - 1 / cMT - ε) * (Ncount T (2 * T) : ℝ) ≤ N0star T (2 * T) := by
  sorry

/-- **Theorem D**, simple zeros: with the optimal window, at least 2 − 1/c₁* (= 0.67250…) of the zeros are
*simple and* on the critical line (the same constant as for N₀*). -/
theorem montgomery_taylor_simple_on_critical_line_mult :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 - 1 / cMT - ε) * (Ncount T (2 * T) : ℝ) ≤ N0simple T (2 * T) := by
  sorry

/-- cumulative form: liminf_{T→∞} N₀ˢ(T)/N(T) ≥ 2 − 1/c₁*. -/
theorem montgomery_taylor_simple_on_critical_line_mult_cumulative :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 - 1 / cMT - ε) * (Ncount 0 T : ℝ) ≤ N0simple 0 T := by
  sorry

/-- **Theorem D**, distinct zeros: at least (3 − 1/c₁*)/2 (= 0.83625…) of the zeros are distinct. -/
theorem montgomery_taylor_distinct_mult :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (3 / 2 - cMT⁻¹ / 2 - ε) * (Ncount T (2 * T) : ℝ) ≤ Ndist T (2 * T) := by
  sorry

/-- cumulative form: liminf_{T→∞} N_d(T)/N(T) ≥ (3 − 1/c₁*)/2. -/
theorem montgomery_taylor_distinct_mult_cumulative :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (3 / 2 - cMT⁻¹ / 2 - ε) * (Ncount 0 T : ℝ) ≤ Ndist 0 T := by
  sorry

/-- **Theorem E — Dirichlet L-functions**: for every primitive Dirichlet character χ modulo q > 1,
at least 2/3 of the nontrivial zeros of L(s,χ) with T < Im ρ ≤ 2T (counted with multiplicity) are
matched by distinct zeros on the critical line, for all large T. -/
theorem dirichlet_two_thirds_on_critical_line
    {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) (hq : 1 < q) (hχ : χ.IsPrimitive) :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 / 3 - ε) * (NcountL χ T (2 * T) : ℝ) ≤ N0starL χ T (2 * T) := by
  sorry

/-- **Theorem E**: for every primitive Dirichlet character χ mod q > 1, at least 2/3 of the
nontrivial zeros of L(s,χ) are simple and on the critical line (dyadic windows). -/
theorem dirichlet_two_thirds_simple_on_critical_line
    {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) (hq : 1 < q) (hχ : χ.IsPrimitive) :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 / 3 - ε) * (NcountL χ T (2 * T) : ℝ) ≤ N0simpleL χ T (2 * T) := by
  sorry

/-- **Theorem E**: at least 5/6 of the nontrivial zeros of L(s,χ) are distinct (χ primitive
mod q > 1; dyadic windows). -/
theorem dirichlet_five_sixths_distinct
    {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) (hq : 1 < q) (hχ : χ.IsPrimitive) :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (5 / 6 - ε) * (NcountL χ T (2 * T) : ℝ) ≤ NdistL χ T (2 * T) := by
  sorry

/-- **Theorem E, "Theorem D holds likewise"**: for χ primitive mod q > 1, liminf_{T→∞}
N*_{0,χ}(T,2T)/N_χ(T,2T) ≥ 2 − 1/c₁* (= 0.67250…). -/
theorem dirichlet_montgomery_taylor_on_critical_line
    {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) (hq : 1 < q) (hχ : χ.IsPrimitive) :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 - 1 / cMT - ε) * (NcountL χ T (2 * T) : ℝ) ≤ N0starL χ T (2 * T) := by
  sorry

/-- **Theorem E (optimal window)**: at least 2 − 1/c₁* (= 0.67250…) of the zeros of L(s,χ)
are simple and on the critical line. -/
theorem dirichlet_montgomery_taylor_simple_on_critical_line_mult
    {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) (hq : 1 < q) (hχ : χ.IsPrimitive) :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (2 - 1 / cMT - ε) * (NcountL χ T (2 * T) : ℝ) ≤ N0simpleL χ T (2 * T) := by
  sorry

/-- **Theorem E (optimal window)**: at least (3 − 1/c₁*)/2 (= 0.83625…) of the zeros of
L(s,χ) are distinct. -/
theorem dirichlet_montgomery_taylor_distinct_mult
    {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) (hq : 1 < q) (hχ : χ.IsPrimitive) :
    ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀, (3 / 2 - cMT⁻¹ / 2 - ε) * (NcountL χ T (2 * T) : ℝ) ≤ NdistL χ T (2 * T) := by
  sorry

end
```

## Deviations

none

## Axiom reports (`scripts/PrintAxioms.lean` of the project, plain `lean`, sandboxed)

```
'two_thirds_on_critical_line' depends on axioms: [propext, Classical.choice, Quot.sound]
'two_thirds_on_critical_line_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
'two_thirds_simple_on_critical_line' depends on axioms: [propext, Classical.choice, Quot.sound]
'two_thirds_simple_on_critical_line_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
'five_sixths_distinct' depends on axioms: [propext, Classical.choice, Quot.sound]
'five_sixths_distinct_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
'montgomery_taylor_on_critical_line' depends on axioms: [propext, Classical.choice, Quot.sound]
'montgomery_taylor_simple_on_critical_line_mult' depends on axioms: [propext, Classical.choice, Quot.sound]
'montgomery_taylor_simple_on_critical_line_mult_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
'montgomery_taylor_distinct_mult' depends on axioms: [propext, Classical.choice, Quot.sound]
'montgomery_taylor_distinct_mult_cumulative' depends on axioms: [propext, Classical.choice, Quot.sound]
'dirichlet_two_thirds_on_critical_line' depends on axioms: [propext, Classical.choice, Quot.sound]
'dirichlet_two_thirds_simple_on_critical_line' depends on axioms: [propext, Classical.choice, Quot.sound]
'dirichlet_five_sixths_distinct' depends on axioms: [propext, Classical.choice, Quot.sound]
'dirichlet_montgomery_taylor_on_critical_line' depends on axioms: [propext, Classical.choice, Quot.sound]
'dirichlet_montgomery_taylor_simple_on_critical_line_mult' depends on axioms: [propext, Classical.choice, Quot.sound]
'dirichlet_montgomery_taylor_distinct_mult' depends on axioms: [propext, Classical.choice, Quot.sound]
```

## What a PASS means

1. The theorems the proof files prove are the statements above, with every definition they mention identical on both sides.
2. The proofs rest on no axiom other than the three listed.
3. Lean's kernel and nanoda re-checked the exported proof terms and everything they depend on, Mathlib's part included.

## What it does not mean

- It is not a check that the Lean statements match the paper's English, nor of the paper itself. The statements are the `Challenge.lean` printed above; read it. They are proportions of zeros in windows `(T, 2T]` for large `T`, in the ε-form shown, counted with multiplicity on the left and as distinct points on the right.
- It is not the Riemann Hypothesis and says nothing about any individual zero. A proportion of zeros on the line, however large, is not a statement about every zero.
- It is an independent repetition of a check Anthropic reports having run itself (Comparator + NanoDa, AUDIT.md of the project); it is not a registry admission and not a first verification.
- It trusts: Lean's kernel and the released toolchain and NanoDa; Comparator and lean4export; Mathlib's definitions and its prebuilt cache; the project's challenge files and lakefile (pinned by sha256); landrun, Landlock, systemd and the Linux kernel for the sandbox; this machine and whoever operated it.

## Facts recorded

| key | value |
|---|---|
| `addon_after` | unmodified |
| `addon_manifest_sha256` | a20b1b1d9e5dff52cbd6aaef82119172ef87cf5ab160e039d15f94f73f0b1086 |
| `af_unix_restricted` | yes |
| `attempt_started_zeta23-main` | cold |
| `audit_rc` | 0 |
| `comparator_build_toolchain` | leanprover/lean4:v4.33.0-rc2 |
| `comparator_commit` | 75c730e9b6ef5c2c3b334fad7c3d51fe20624c88 |
| `comparator_sha256` | 7f05e2d5ef6826954515e0d31685b85996cd4bc366104f762fe07a7219a12bd1 |
| `config_used` | comparator.json |
| `config_used_sha256` | 610d95c6c84f13b3e2238b476fe45f0b28567108f536f67a0b9ed1586a2c68f1 |
| `dep_lakefiles_after` | unchanged |
| `dep_lakefiles_digest` | e8d5f73eecc1503bfc917b38acca36ec2d0180c3c6fbfa4e05b975d47f5ba4d1 |
| `deps_after` | unchanged |
| `deps_compiled_files` | 52108 |
| `fm_commit` | 16a5ce41304fcdaea4e0be7c132e1c361dc26da5 |
| `job_af_unix_zeta23-main` | denied |
| `job_boot_id_zeta23-main` | 03b05777-b2cf-4d67-a0bc-6f8134e30cbb |
| `job_stack_kb_zeta23-main` | 1048576 |
| `landrun_commit` | 811cfff51ceaf3d9843708aa6d22e9b84ccac8b4 |
| `landrun_sha256` | 63a60219f6bd7bf61341730e95d1fcfd4b9d877e48d5d24759de010f6fbc6ea9 |
| `landrun_static` | yes |
| `landrun_version` | landrun version 0.1.18 |
| `launch_cpus_zeta23-main` | 8 |
| `launch_mem_gb_zeta23-main` | 37 |
| `launch_mode_zeta23-main` | systemd-user RestrictAddressFamilies=~AF_UNIX SystemCallArchitectures=native OOMPolicy=continue LimitSTACK=1G |
| `launch_swap_gb_zeta23-main` | 39 |
| `lean4export_commit` | 9fb131bb100eb32ccf6836f14e4f8328d13b6792 |
| `lean4export_sha256` | 8d10cd2596176885cc4f8e9fa771ff271e2d57a28c5676542e01dd8e1d4300d6 |
| `lean_prefix` | /home/qrh/.elan/toolchains/leanprover--lean4---v4.33.0-rc2 |
| `lean_sha256_lake` | 60330ab6f07dce20f3fa9ebb08e8b984ea9549eac172afeb15d9d2227060e2b3 |
| `lean_sha256_lean` | e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550 |
| `lean_sha256_libInit_shared.so` | 2f96493ac9046f64ec7bcb78102a4c1e7cd9a7042487f246af45eda8a96667f5 |
| `lean_sha256_libLake_shared.so` | feb2914d056638438613284b1f98278579ff8d8d99d0567e9823167806d150c0 |
| `lean_sha256_libleanshared.so` | 0e2ffc1639d133cfccf1552c0d59772b77ed56e3e0c5a00e33d8c7c324a9470f |
| `lean_sha256_libleanshared_1.so` | 2f96493ac9046f64ec7bcb78102a4c1e7cd9a7042487f246af45eda8a96667f5 |
| `lean_sha256_libleanshared_2.so` | 2f96493ac9046f64ec7bcb78102a4c1e7cd9a7042487f246af45eda8a96667f5 |
| `lean_toolchain_verified` | yes (7 files match the pinned sha256 of the v4.33.0-rc2 release) |
| `lean_version` | Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release) |
| `main_kit_verdict` | PASS |
| `main_state` | finished |
| `mathlib_commit` | 51e6992efd06126df61a496bebf8f49482a4e129 |
| `mathlib_oleans` | 8313 |
| `nanoda_commit` | 68d5ca9db226849b41a6fff59d796ff19d0a8840 |
| `nanoda_enabled` | yes |
| `nanoda_sha256` | d883b3139c9aea661a861f60aecaf14631d5c0a929b8e49a100e2173dd3dfb15 |
| `probes_boot_id` | 03b05777-b2cf-4d67-a0bc-6f8134e30cbb |
| `probes_boot_id_zeta23-main` | 03b05777-b2cf-4d67-a0bc-6f8134e30cbb |
| `qrh_work` | /home/qrh/qrh-zeta23-work |
| `rustc_version` | rustc 1.93.1 (01f6ddf75 2026-02-11) (built from a source tarball) |
| `sandbox_enforcing` | yes |
| `sandbox_tcp` | blocked |
| `tools_after` | unchanged |
| `trusted_files_after` | unchanged |
| `z23_dir` | /home/qrh/qrh-zeta23-work/formal-math/zeta23 |
| `z23_sources_files` | 316 |
| `z23_sources_lines` | 102265 |

## Last lines of Comparator's log

```
Note: This linter can be disabled with `set_option linter.unusedSectionVars false`
✔ [8880/8887] Built Zeta23.ThmDE.Traces (7.9s)
✔ [8881/8887] Built Zeta23.ThmE.Final (4.5s)
✔ [8882/8887] Built Zeta23.ThmDE.Concrete (6.0s)
✔ [8883/8887] Built Zeta23.ThmE.Mult (9.7s)
✔ [8884/8887] Built Zeta23.ThmDE.Final (6.1s)
✔ [8885/8887] Built Zeta23.ThmDE.Mult (12s)
✔ [8886/8887] Built Solution (3.8s)
Build completed successfully (8887 jobs).
Exporting #[Nat, String, String.mk, Char, Quot, Quot.mk, Quot.lift, Quot.ind, two_thirds_on_critical_line, two_thirds_on_critical_line_cumulative, two_thirds_simple_on_critical_line, two_thirds_simple
Running nanoda kernel on solution
Nanoda kernel accepts the solution
Running Lean default kernel on solution.
Lean default kernel accepts the solution
Your solution is okay!
```

