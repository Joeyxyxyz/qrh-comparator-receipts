# MNF.RH library (v3) on top of the checked 7/8 theorem

**Result: MNF_LIBRARY=ACCEPTED**

Main kit verdict for `OAI.riemannZeta_ne_zero_of_seven_eighths_lt_re`: **PASS** (RECEIPT.md). The library run below is a second, separate Comparator run: its challenge (`MNFChallenges/RH.lean`, every proof `sorry`) states the MNF theorems and the definitions they use; its solution (`MNF.RH.Unconditional`) proves them, using OpenAI's theorem where the 7/8 region is needed. Comparator built both in its sandbox, exported both, and checked that every theorem statement and every definition (name, type and body) agrees and that the proofs use no axiom beyond propext, Quot.sound, Classical.choice.

- Comparator job `mnf-library-v3`: exit 0, started 2026-10-29T05:56:47Z, ended 2026-10-29T06:10:47Z
- launch: systemd-user RestrictAddressFamilies=~AF_UNIX SystemCallArchitectures=native OOMPolicy=continue LimitSTACK=1G; AF_UNIX sockets in the job: denied
- 87 theorems named in the challenge config; 41 definitions in the challenge, all compared by name, type and body (definition_names is empty)
- tree: a copy of the verified tree at `/home/qrh/qrh-work/mnf-tree`, plus `MNF/`, `SturmLiouville/`, `MNFChallenges/`, `MNF_Audit.lean` and three `lean_lib` lines appended to `lakefile.lean`

## What was proved

As printed by Lean (`#check`), from the audit compile:

```lean
MNF.RH.zeta_order_ge_one {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : 1 ≤ MNF.RH.zeta_order ρ
MNF.RH.order_one_iff_deriv {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.zeta_order ρ = 1 ↔ deriv riemannZeta ρ ≠ 0
MNF.RH.deriv_zero_of_high_order {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) (h2 : 2 ≤ MNF.RH.zeta_order ρ) :
  deriv riemannZeta ρ = 0
MNF.RH.allZerosSimple_iff_derivativeNonvanishing : MNF.RH.AllZerosSimple ↔ MNF.RH.DerivativeNonvanishing
MNF.RH.nontrivial_zero_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.is_nontrivial_zero (1 - ρ)
MNF.RH.deriv_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  deriv riemannZeta (1 - ρ) = -(MNF.RH.feFactor ρ * deriv riemannZeta ρ)
MNF.RH.deriv_ne_zero_reflect_iff {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  deriv riemannZeta (1 - ρ) ≠ 0 ↔ deriv riemannZeta ρ ≠ 0
MNF.RH.analyticOrderAt_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) :
  analyticOrderAt riemannZeta (1 - ρ) = analyticOrderAt riemannZeta ρ
MNF.RH.zeta_order_reflect {ρ : ℂ} (h : MNF.RH.is_nontrivial_zero ρ) : MNF.RH.zeta_order (1 - ρ) = MNF.RH.zeta_order ρ
MNF.RH.shifted_symmetric {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : -x ∈ MNF.RH.ShiftedZeroSpectrum
MNF.RH.in_strip_of_zero {s : ℂ} (hs : riemannZeta s = 0) (htriv : ¬∃ n, s = -2 * (↑n + 1)) (h1 : s ≠ 1) :
  0 < s.re ∧ s.re < 1
MNF.RH.riemannHypothesis_iff_strip : RiemannHypothesis ↔ ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2
MNF.RH.riemannHypothesis_iff_shifted_subset_zero : RiemannHypothesis ↔ MNF.RH.ShiftedZeroSpectrum ⊆ {0}
MNF.RH.shifted_bounded {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| < 1 / 2
MNF.RH.tau_threshold {S : Set ℝ} {Δ : ℝ} (hgap : MNF.RH.SpectralGapProperty S Δ) (hbound : ∀ x ∈ S, |x| < Δ) : S ⊆ {0}
MNF.RH.riemannHypothesis_iff_gap_half {Δ : ℝ} (hΔ : 1 / 2 ≤ Δ) :
  RiemannHypothesis ↔ MNF.RH.SpectralGapProperty MNF.RH.ShiftedZeroSpectrum Δ
MNF.RH.shifted_bounded_of_zeroFree {θ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) {x : ℝ}
  (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| ≤ θ - 1 / 2
MNF.RH.riemannHypothesis_iff_gap_of_zeroFree {θ Δ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) (hΔ : θ - 1 / 2 < Δ) :
  RiemannHypothesis ↔ MNF.RH.SpectralGapProperty MNF.RH.ShiftedZeroSpectrum Δ
MNF.RH.riemannHypothesis_iff_remaining_strip {θ : ℝ} (h : MNF.RH.ZeroFreeRightOf θ) :
  RiemannHypothesis ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re ≤ θ → riemannZeta s ≠ 0
MNF.RH.gap_below_bound_insufficient {b Δ : ℝ} (hΔ : 0 < Δ) (hb : Δ < b) :
  ∃ S ⊆ Set.Ioo (-b) b, (∀ x ∈ S, -x ∈ S) ∧ MNF.RH.SpectralGapProperty S Δ ∧ S ≠ {0}
MNF.RH.symmetric_bounded_not_on_line :
  ¬∀ (Z : Set ℂ), (∀ ρ ∈ Z, 1 - ρ ∈ Z) → (∀ ρ ∈ Z, ρ.re ≤ 7 / 8) → ∀ ρ ∈ Z, ρ.re = 1 / 2
MNF.RH.sign_gate_trivial {S : Set ℝ} (hS : ∀ x ∈ S, -x ∈ S) : MNF.RH.signGate S = {0}
MNF.RH.sign_gate_shifted : MNF.RH.signGate MNF.RH.ShiftedZeroSpectrum = {0}
MNF.RH.nullify_dilation {l : ℝ} (hl : 0 < l) (Δ x : ℝ) : MNF.RH.nullify (l * Δ) (l * x) = l * MNF.RH.nullify Δ x
MNF.RH.gap_iff_nullify_id (S : Set ℝ) (Δ : ℝ) : MNF.RH.SpectralGapProperty S Δ ↔ ∀ x ∈ S, MNF.RH.nullify Δ x = x
MNF.RH.delta_from_ratio_38_insufficient :
  1 / 2 * (3 / 8) = 3 / 16 ∧
    ∃ S ⊆ Set.Ioo (-(3 / 8)) (3 / 8), (∀ x ∈ S, -x ∈ S) ∧ MNF.RH.SpectralGapProperty S (3 / 16) ∧ S ≠ {0}
MNF.RH.rh_of_gap {Δ : ℝ} (hΔ : 1 / 2 ≤ Δ) (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.rh_of_gap_of_zeroFree {θ Δ : ℝ} (hθ : MNF.RH.ZeroFreeRightOf θ) (hΔ : θ - 1 / 2 < Δ)
  (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.gap_of_rh (h : RiemannHypothesis) (Δ : ℝ) : MNF.RH.SpectralGapHyp Δ
MNF.RH.multiplicityBoundOne_iff_allZerosSimple : MNF.RH.MultiplicityBoundOne ↔ MNF.RH.AllZerosSimple
MNF.RH.derivativeNonvanishing_of_left
  (h : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re ≤ 1 / 2 → deriv riemannZeta ρ ≠ 0) : MNF.RH.DerivativeNonvanishing
MNF.RH.allZerosSimple_of_speiser_and_double_zero_hyp (hRH : RiemannHypothesis) (hSp : MNF.RH.SpeiserTheorem)
  (hDZ : MNF.RH.DoubleZeroForcesLeftDerivZero) : MNF.RH.AllZerosSimple
MNF.RH.allZerosSimple_of_rh_of_line (hRH : RiemannHypothesis)
  (hline : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2 → deriv riemannZeta ρ ≠ 0) : MNF.RH.AllZerosSimple
MNF.RH.rh_of_symmetric_operator.{u_1} {E : Type u_1} [NormedAddCommGroup E] [InnerProductSpace ℂ E] (T : E →ₗ[ℂ] E)
  (hT : T.IsSymmetric)
  (hspec : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → Module.End.HasEigenvalue T ((ρ - 1 / 2) / Complex.I)) :
  RiemannHypothesis
MNF.RH.spectralGapHyp_iff_zeroFree_strip {Δ : ℝ} :
  MNF.RH.SpectralGapHyp Δ ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re < 1 / 2 + Δ → riemannZeta s ≠ 0
MNF.RH.spectralGapHyp_three_eighths_iff_of (h : MNF.RH.ZeroFreeRightOf (7 / 8)) :
  MNF.RH.SpectralGapHyp (3 / 8) ↔ ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2 ∨ ρ.re = 1 / 8 ∨ ρ.re = 7 / 8
MNF.RH.zeroFree_seven_eighths : MNF.RH.ZeroFreeRightOf (7 / 8)
MNF.RH.nontrivial_zero_re_le_seven_eighths {ρ : ℂ} (hρ : MNF.RH.is_nontrivial_zero ρ) : ρ.re ≤ 7 / 8
MNF.RH.shifted_bounded_three_eighths {x : ℝ} (hx : x ∈ MNF.RH.ShiftedZeroSpectrum) : |x| ≤ 3 / 8
MNF.RH.riemannHypothesis_iff_gap_three_eighths {Δ : ℝ} (hΔ : 3 / 8 < Δ) : RiemannHypothesis ↔ MNF.RH.SpectralGapHyp Δ
MNF.RH.riemannHypothesis_iff_remaining_strip_seven_eighths :
  RiemannHypothesis ↔ ∀ (s : ℂ), 1 / 2 < s.re → s.re ≤ 7 / 8 → riemannZeta s ≠ 0
MNF.RH.rh_of_gap_three_eighths {Δ : ℝ} (hΔ : 3 / 8 < Δ) (h : MNF.RH.SpectralGapHyp Δ) : RiemannHypothesis
MNF.RH.spectralGapHyp_three_eighths_iff :
  MNF.RH.SpectralGapHyp (3 / 8) ↔ ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ρ.re = 1 / 2 ∨ ρ.re = 1 / 8 ∨ ρ.re = 7 / 8
MNF.RH.rh_of_band_seven_eighths (h : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → 1 / 2 < ρ.re → 7 / 8 < ρ.re) :
  RiemannHypothesis
MNF.RH.mem_zerosIn {T₁ T₂ : ℝ} {ρ : ℂ} : ρ ∈ MNF.RH.zerosIn T₁ T₂ ↔ MNF.RH.is_nontrivial_zero ρ ∧ T₁ < ρ.im ∧ ρ.im ≤ T₂
MNF.RH.zerosIn_subset_zetaZeros (T₁ T₂ : ℝ) : MNF.RH.zerosIn T₁ T₂ ⊆ MNF.RH.ZetaZeros
MNF.RH.zerosIn_mono {T₁ T₁' T₂ T₂' : ℝ} (h₁ : T₁' ≤ T₁) (h₂ : T₂ ≤ T₂') : MNF.RH.zerosIn T₁ T₂ ⊆ MNF.RH.zerosIn T₁' T₂'
MNF.RH.zerosIn_subset_box (T₁ T₂ : ℝ) : MNF.RH.zerosIn T₁ T₂ ⊆ Set.Icc 0 1 ×ℂ Set.Icc T₁ T₂ ∩ riemannZetaZeros
MNF.RH.zerosIn_finite (T₁ T₂ : ℝ) : (MNF.RH.zerosIn T₁ T₂).Finite
MNF.RH.Ncount_eq_sum {T₁ T₂ : ℝ} (hfin : (MNF.RH.zerosIn T₁ T₂).Finite) :
  MNF.RH.Ncount T₁ T₂ = ∑ ρ ∈ hfin.toFinset, MNF.RH.zeta_order ρ
MNF.RH.Ndist_eq_sum_ones {T₁ T₂ : ℝ} (hfin : (MNF.RH.zerosIn T₁ T₂).Finite) :
  MNF.RH.Ndist T₁ T₂ = ∑ _ρ ∈ hfin.toFinset, 1
MNF.RH.Ndist_le_Ncount (T₁ T₂ : ℝ) : MNF.RH.Ndist T₁ T₂ ≤ MNF.RH.Ncount T₁ T₂
MNF.RH.N0star_le_Ndist (T₁ T₂ : ℝ) : MNF.RH.N0star T₁ T₂ ≤ MNF.RH.Ndist T₁ T₂
MNF.RH.N0simple_le_N0star (T₁ T₂ : ℝ) : MNF.RH.N0simple T₁ T₂ ≤ MNF.RH.N0star T₁ T₂
MNF.RH.riemannHypothesis_iff_window_counts : RiemannHypothesis ↔ ∀ (T₁ T₂ : ℝ), MNF.RH.N0star T₁ T₂ = MNF.RH.Ndist T₁ T₂
MNF.RH.allZerosSimple_iff_window_counts :
  MNF.RH.AllZerosSimple ↔ ∀ (T₁ T₂ : ℝ), MNF.RH.Ncount T₁ T₂ = MNF.RH.Ndist T₁ T₂
MNF.RH.N0simple_eq_deriv_form (T₁ T₂ : ℝ) :
  MNF.RH.N0simple T₁ T₂ = (MNF.RH.zerosIn T₁ T₂ ∩ {ρ | ρ.re = 1 / 2} ∩ {ρ | deriv riemannZeta ρ ≠ 0}).ncard
MNF.RH.gap_iff_zeroFreeBand (Δ : ℝ) : MNF.RH.SpectralGapHyp Δ ↔ MNF.RH.ZeroFreeBand Δ
MNF.RH.gap_of_right_side {Δ : ℝ} (h : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → 1 / 2 < ρ.re → 1 / 2 + Δ ≤ ρ.re) :
  MNF.RH.SpectralGapHyp Δ
MNF.RH.rh_of_band_of_zeroFree {θ : ℝ} (hθ : MNF.RH.ZeroFreeRightOf θ)
  (h : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → 1 / 2 < ρ.re → θ < ρ.re) : RiemannHypothesis
MNF.RH.multipleZeroKillsGap_iff : MNF.RH.MultipleZeroKillsGap ↔ RiemannHypothesis → MNF.RH.AllZerosSimple
MNF.RH.fischerForward_iff : MNF.RH.FischerForward ↔ RiemannHypothesis → MNF.RH.AllZerosSimple
MNF.RH.re_eq_half_of_real_eigenvalue {ρ : ℂ} {l : ℝ} (h : ↑l = (ρ - 1 / 2) / Complex.I) : ρ.re = 1 / 2
MNF.RH.rh_of_realSpectrumRealization {Λ : Set ℝ} (h : MNF.RH.RealSpectrumRealization Λ) : RiemannHypothesis
MNF.RH.allZerosSimple_of_multiplicity_dictionary {Λ : Set ℝ} (mult : ℝ → ℕ)
  (hdict : ∀ (ρ : ℂ), MNF.RH.is_nontrivial_zero ρ → ∃ l ∈ Λ, mult l = MNF.RH.zeta_order ρ)
  (hsimple : ∀ l ∈ Λ, mult l = 1) : MNF.RH.AllZerosSimple
MNF.RH.gap_of_mechanism {Δ : ℝ} (M : MNF.RH.GapMechanism Δ) : MNF.RH.SpectralGapHyp Δ
MNF.RH.mechanism_of_gap {Δ : ℝ} (h : MNF.RH.SpectralGapHyp Δ) : MNF.RH.GapMechanism Δ
MNF.RH.gapMechanism_iff (Δ : ℝ) : MNF.RH.GapMechanism Δ ↔ MNF.RH.SpectralGapHyp Δ
MNF.RH.probe_balance (ρ : ℂ) : MNF.RH.NorthProbe ρ + MNF.RH.SouthProbe ρ = 0
MNF.RH.probe_reflect (ρ : ℂ) : MNF.RH.NorthProbe (1 - ρ) = MNF.RH.SouthProbe ρ
MNF.RH.probes_zero_iff (ρ : ℂ) : MNF.RH.NorthProbe ρ = 0 ∧ MNF.RH.SouthProbe ρ = 0 ↔ ρ.re = 1 / 2
wronskian_constant_same_eigenvalue (V : ℝ → ℝ) (eigval : ℝ) (u v : ℝ → ℝ)
  (hu : IsSturmLiouvilleEigenfunction V eigval u) (hv : IsSturmLiouvilleEigenfunction V eigval v) :
  ∃ C, ∀ (x : ℝ), wronskian u v x = C
wronskian_zero_of_l2 (V : ℝ → ℝ) (eigval : ℝ) (hV : IsConfiningPotential V) (u v : ℝ → ℝ)
  (hu : IsSturmLiouvilleEigenfunction V eigval u) (hv : IsSturmLiouvilleEigenfunction V eigval v) (x : ℝ) :
  wronskian u v x = 0
linearly_dependent_of_wronskian_zero (V : ℝ → ℝ) (eigval : ℝ) (hV_cont : Continuous V) (u v : ℝ → ℝ)
  (hu : IsSturmLiouvilleEigenfunction V eigval u) (hv : IsSturmLiouvilleEigenfunction V eigval v)
  (hW : ∀ (x : ℝ), wronskian u v x = 0) : ∃ c, ∀ (x : ℝ), v x = c * u x
sturm_liouville_simple_eigenvalues (V : ℝ → ℝ) (hV : IsConfiningPotential V) (eigval : ℝ) : IsSimpleEigenvalue V eigval
MNF.RH.realization_forces_line {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) {ρ : ℂ} (hρ : MNF.RH.is_nontrivial_zero ρ) : ρ.re = 1 / 2
MNF.RH.rh_of_realization (hR : MNF.RH.SchrodingerRealization) : RiemannHypothesis
MNF.RH.realSpectrumRealization_of_realization {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) : MNF.RH.RealSpectrumRealization (Set.range level)
MNF.RH.eigenvalue_simple_of_realization {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) (ρ : ℂ) : IsSimpleEigenvalue V (level ρ)
MNF.RH.eigenfunction_unique_of_realization {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) {ρ : ℂ} (hρ : MNF.RH.is_nontrivial_zero ρ) (v : ℝ → ℝ)
  (hv : IsSturmLiouvilleEigenfunction V (level ρ) v) : ∃ c, ∀ (x : ℝ), v x = c * u ρ x
MNF.RH.allZerosSimple_of_realization {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) (hd : MNF.RH.MultiplicityDictionary V level) : MNF.RH.AllZerosSimple
MNF.RH.derivativeNonvanishing_of_realization {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) (hd : MNF.RH.MultiplicityDictionary V level) :
  MNF.RH.DerivativeNonvanishing
MNF.RH.multiplicityDictionary_iff {V : ℝ → ℝ} {level : ℂ → ℝ} {u : ℂ → ℝ → ℝ}
  (hR : MNF.RH.IsSchrodingerRealization V level u) : MNF.RH.MultiplicityDictionary V level ↔ MNF.RH.AllZerosSimple
MNF.RH.N0_le_Ncount (T₁ T₂ : ℝ) : MNF.RH.N0 T₁ T₂ ≤ MNF.RH.Ncount T₁ T₂
MNF.RH.NOff_le_Ncount (δ T₁ T₂ : ℝ) : MNF.RH.NOff δ T₁ T₂ ≤ MNF.RH.Ncount T₁ T₂
MNF.RH.gap_forces_NOff_eq {Δ : ℝ} (hΔ : 0 < Δ) (hgap : MNF.RH.SpectralGapHyp Δ) (T₁ T₂ : ℝ) :
  MNF.RH.Ncount T₁ T₂ = MNF.RH.N0 T₁ T₂ + MNF.RH.NOff Δ T₁ T₂
MNF.RH.on_line_density_one_of_gap (hBL : MNF.RH.BohrLandau) (hN : MNF.RH.NcountSuperlinear) {Δ : ℝ} (hΔ : 0 < Δ)
  (hgap : MNF.RH.SpectralGapHyp Δ) (ε : ℝ) : ε > 0 → ∃ T₀, ∀ T ≥ T₀, (1 - ε) * ↑(MNF.RH.Ncount 0 T) ≤ ↑(MNF.RH.N0 0 T)
```

## How to read this

- Everything in `MNF/RH/Core.lean`, `Gap.lean` and `Hypotheses.lean` is proved from Mathlib alone; the theorems whose names end in `_seven_eighths` / `_three_eighths` (`Unconditional.lean`) use OpenAI's theorem and are exactly as reliable as the main kit's PASS.
- The Riemann Hypothesis is not among the theorems. `riemannHypothesis_iff_gap_three_eighths` says the MNF gap hypothesis at any Δ > 3/8 *is* RH; `gap_below_bound_insufficient` says a gap at Δ ≤ 3/8 cannot give it. `riemannHypothesis_iff_remaining_strip_seven_eighths` says what is left: no zeros with 1/2 < Re s ≤ 7/8.
- `SpeiserTheorem` and `DoubleZeroForcesLeftDerivZero` are hypotheses (explicit arguments), not axioms; nothing here asserts them.
- `spectralGapHyp_iff_zeroFree_strip` says the gap hypothesis at `Δ` is exactly a zero-free strip `1/2 < Re s < 1/2 + Δ`; `spectralGapHyp_three_eighths_iff` is the boundary case `Δ = 3/8` with the 7/8 region (zeros on `Re s = 7/8` are not excluded by it, so this is not RH).

## Axiom reports

| theorem | axioms |
|---|---|
| `MNF.RH.zeta_order_ge_one` | Classical.choice, Quot.sound, propext |
| `MNF.RH.order_one_iff_deriv` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_zero_of_high_order` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_iff_derivativeNonvanishing` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nontrivial_zero_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.deriv_ne_zero_reflect_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.analyticOrderAt_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zeta_order_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_symmetric` | Classical.choice, Quot.sound, propext |
| `MNF.RH.in_strip_of_zero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_shifted_subset_zero` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded` | Classical.choice, Quot.sound, propext |
| `MNF.RH.tau_threshold` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_half` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_remaining_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_below_bound_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.RH.symmetric_bounded_not_on_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.sign_gate_trivial` | Classical.choice, Quot.sound, propext |
| `MNF.RH.sign_gate_shifted` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nullify_dilation` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_iff_nullify_id` | Classical.choice, Quot.sound, propext |
| `MNF.RH.delta_from_ratio_38_insufficient` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_of_rh` | Classical.choice, Quot.sound, propext |
| `MNF.RH.multiplicityBoundOne_iff_allZerosSimple` | Classical.choice, Quot.sound, propext |
| `MNF.RH.derivativeNonvanishing_of_left` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_speiser_and_double_zero_hyp` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_rh_of_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_symmetric_operator` | Classical.choice, Quot.sound, propext |
| `MNF.RH.spectralGapHyp_iff_zeroFree_strip` | Classical.choice, Quot.sound, propext |
| `MNF.RH.spectralGapHyp_three_eighths_iff_of` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zeroFree_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.nontrivial_zero_re_le_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.shifted_bounded_three_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_gap_three_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_remaining_strip_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_gap_three_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.spectralGapHyp_three_eighths_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_band_seven_eighths` | Classical.choice, Quot.sound, propext |
| `MNF.RH.mem_zerosIn` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_subset_zetaZeros` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_mono` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_subset_box` | Classical.choice, Quot.sound, propext |
| `MNF.RH.zerosIn_finite` | Classical.choice, Quot.sound, propext |
| `MNF.RH.Ncount_eq_sum` | Classical.choice, Quot.sound, propext |
| `MNF.RH.Ndist_eq_sum_ones` | Classical.choice, Quot.sound, propext |
| `MNF.RH.Ndist_le_Ncount` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0star_le_Ndist` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0simple_le_N0star` | Classical.choice, Quot.sound, propext |
| `MNF.RH.riemannHypothesis_iff_window_counts` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_iff_window_counts` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0simple_eq_deriv_form` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_iff_zeroFreeBand` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_of_right_side` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_band_of_zeroFree` | Classical.choice, Quot.sound, propext |
| `MNF.RH.multipleZeroKillsGap_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.fischerForward_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.re_eq_half_of_real_eigenvalue` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_realSpectrumRealization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_multiplicity_dictionary` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_of_mechanism` | Classical.choice, Quot.sound, propext |
| `MNF.RH.mechanism_of_gap` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gapMechanism_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.probe_balance` | Classical.choice, Quot.sound, propext |
| `MNF.RH.probe_reflect` | Classical.choice, Quot.sound, propext |
| `MNF.RH.probes_zero_iff` | Classical.choice, Quot.sound, propext |
| `wronskian_constant_same_eigenvalue` | Classical.choice, Quot.sound, propext |
| `wronskian_zero_of_l2` | Classical.choice, Quot.sound, propext |
| `linearly_dependent_of_wronskian_zero` | Classical.choice, Quot.sound, propext |
| `sturm_liouville_simple_eigenvalues` | Classical.choice, Quot.sound, propext |
| `MNF.RH.realization_forces_line` | Classical.choice, Quot.sound, propext |
| `MNF.RH.rh_of_realization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.realSpectrumRealization_of_realization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.eigenvalue_simple_of_realization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.eigenfunction_unique_of_realization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.allZerosSimple_of_realization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.derivativeNonvanishing_of_realization` | Classical.choice, Quot.sound, propext |
| `MNF.RH.multiplicityDictionary_iff` | Classical.choice, Quot.sound, propext |
| `MNF.RH.N0_le_Ncount` | Classical.choice, Quot.sound, propext |
| `MNF.RH.NOff_le_Ncount` | Classical.choice, Quot.sound, propext |
| `MNF.RH.gap_forces_NOff_eq` | Classical.choice, Quot.sound, propext |
| `MNF.RH.on_line_density_one_of_gap` | Classical.choice, Quot.sound, propext |

## Hashes

```
c768a8b2b1b8cfeea30f7e4f532e490030c611ff3017b23aea919c11a04c8f25  MNF/RH/Core.lean
9419bf81bfddaafe641f0587998d98aade8a663b64f65cdef3bb97466840d343  MNF/RH/Counting.lean
557d26693acb82a3acb791f14ec7089d148b8265752e3019a82b3473a2a54476  MNF/RH/GapDensity.lean
5a008cd5d18eaed26eea66e236cbe5f0f3c7d0bd64a1d449e3232edf78494a71  MNF/RH/Gap.lean
5b3c90e3b39a95fab27cd99b06fed06ea1a61de51cb7b1fa9c836e4d56ec2026  MNF/RH/Hypotheses.lean
99c751678f26c522a22044bf81c436ec769043fb4a960a4d7c34eb12d8b75160  MNF/RH/Reduction.lean
762a7964ac52f25b0511d7c6b89bd7471067efdadcd5f2ea00e627f99c9309ca  MNF/RH/Schrodinger.lean
7e69c0616242cdb90eb08237b9b40ba91e7c0572683907ae94f348e5976ccd56  MNF/RH/Unconditional.lean
efaae3a2a6b1f929754d450d7cbdcef0d6b4d643b29eb2a018a784b4dad8a0fe  SturmLiouville/SimpleEigenvalues.lean
6e759a2cc6ef842379ed5260142de048e226fb681298e103508729139f5c6074  MNFChallenges/Core.lean
7c8eca6a4238b070fa0ff17a3cb4a2c41ce4735b8018e84fd7b5c7cf3ad648b7  MNFChallenges/Counting.lean
a240b391f006c2c5f244c5b93f1aae716c1b1397693f94b7ab6e5a7503b1daed  MNFChallenges/GapDensity.lean
aa95324ef3951b32c1c8936a39dd046bd675d8a298561d5d734888d29bfb8ece  MNFChallenges/Gap.lean
27f5b9c7330316b7d586d7dfb63a0df4489c45e0ef906d38903f5ff81ad87354  MNFChallenges/Hypotheses.lean
8b0f89118c3e761ef0d67fdff445e90742bba14d9976b72b8d145da19b1f3b26  MNFChallenges/Reduction.lean
e39e71a01002befb245903decdaf4b1ad0379cb01baf4d29313fc69f9439f69b  MNFChallenges/RH.lean
5919ac913ce643d69091387babbfab03b986ee8239a3adf14e2fadd907099202  MNFChallenges/Schrodinger.lean
142e79d817880a341a2e6df276421befd48f390d42c5119181ea249b4043b711  MNFChallenges/SturmLiouville.lean
559cc7c1993788162403138db28c3a8f3020934c2174a68f589f11282ba67915  MNFChallenges/RH.json
1c9179c70fdfb873676fbff6bd9ce4dcb8e54470de6fd5923fcc79022bda3a12  MNF_Audit.lean
3ae67f760660f11f8fca9a58dd1dc83347037fc294e7033c330194b2fccb1dd3  lakefile_append.lean
lakefile.lean after the append: 7a9fd35b2df3c848dc1da63c764c23c0d1551e80fff5aeed2c6d1cbedee4c72a
```

## Last lines of Comparator's log

```
info: MNF/RH/Unconditional.lean:66:0: 'MNF.RH.zeroFree_seven_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:67:0: 'MNF.RH.shifted_bounded_three_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:68:0: 'MNF.RH.riemannHypothesis_iff_gap_three_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:69:0: 'MNF.RH.riemannHypothesis_iff_remaining_strip_seven_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:70:0: 'MNF.RH.rh_of_gap_three_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:71:0: 'MNF.RH.spectralGapHyp_three_eighths_iff' depends on axioms: [propext, Classical.choice, Quot.sound]
info: MNF/RH/Unconditional.lean:72:0: 'MNF.RH.rh_of_band_seven_eighths' depends on axioms: [propext, Classical.choice, Quot.sound]
Build completed successfully (7231 jobs).
Exporting #[Quot, Quot.mk, Quot.lift, Quot.ind, MNF.RH.zeta_order_ge_one, MNF.RH.order_one_iff_deriv, MNF.RH.deriv_zero_of_high_order, MNF.RH.allZerosSimple_iff_derivativeNonvanishing, MNF.RH.nontrivi
Running Lean default kernel on solution.
Lean default kernel accepts the solution
Your solution is okay!
```
