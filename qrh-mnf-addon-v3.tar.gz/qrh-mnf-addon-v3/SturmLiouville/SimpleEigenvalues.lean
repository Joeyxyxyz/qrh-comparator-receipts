/-
═══════════════════════════════════════════════════════════════════════
STURM–LIOUVILLE SIMPLE EIGENVALUES — canonical file
(SturmLiouville/SimpleEigenvalues.lean)
═══════════════════════════════════════════════════════════════════════
Consolidated 2026-10-27 from the three corpus variants
  sturm_liouville_master.lean.txt, sturm_liouville_PHASE1_COMPLETE.lean,
  strum_louifinal.lean.txt   (all Aristotle, Lean v4.24.0 / Mathlib f897ebcf, 2026-03-03).

The three files share, character for character, the lemmas kept here.  What is dropped:
  - eventually_nonzero_of_confining_eigenfunction_aux and its copies _v2 … _v9
    (PHASE1 and strum_louifinal: contain `exact?` / `skip`; master: a manually patched
    version using `grind`) — not needed: the capstone goes through `wronskian_zero_of_l2`,
    whose limit lemma `tendsto_zero_and_deriv_zero_of_eigenfunction` never uses them;
  - tendsto_zero_and_deriv_zero_of_eigenfunction_final / _fixed / _fixed_v2 and
    wronskian_zero_of_l2_final (restatements through the dropped chain);
  - sturm_liouville_simple_eigenvalues_proven (duplicate of the capstone);
  - `import Mathlib` → the modules actually used.

Theorem chain (every step kept):
  wronskian_constant_same_eigenvalue, exists_seq_tendsto_zero_of_memLp,
  not_memLp_of_tendsto_deriv_pos, eventually_V_gt_eigenvalue,
  not_memLp_of_zero_and_deriv_pos_and_confining, constant_sign_of_no_zeros,
  tendsto_deriv_zero_of_convex_nonneg_l2, tendsto_zero_of_convex_nonneg_l2_and_deriv,
  is_eigenfunction_neg, zero_of_ode_zero_init, tendsto_zero_and_deriv_zero_of_eigenfunction,
  wronskian_zero_of_l2, linearly_dependent_of_wronskian_zero,
  sturm_liouville_simple_eigenvalues.

Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
-/
import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

set_option linter.mathlibStandardSet false

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 0
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

noncomputable section

def IsConfiningPotential (V : ℝ → ℝ) : Prop :=
  Continuous V ∧ Filter.Tendsto V (Filter.cocompact ℝ) Filter.atTop

def IsSturmLiouvilleEigenfunction (V : ℝ → ℝ) (eigval : ℝ) (u : ℝ → ℝ) : Prop :=
  Differentiable ℝ u ∧
  Differentiable ℝ (deriv u) ∧
  (∀ x, -(deriv (deriv u) x) + V x * u x = eigval * u x) ∧
  u ≠ 0 ∧
  MeasureTheory.MemLp u 2 MeasureTheory.volume

def wronskian (u v : ℝ → ℝ) (x : ℝ) : ℝ :=
  u x * deriv v x - v x * deriv u x

theorem wronskian_constant_same_eigenvalue (V : ℝ → ℝ) (eigval : ℝ)
    (u v : ℝ → ℝ)
    (hu : IsSturmLiouvilleEigenfunction V eigval u)
    (hv : IsSturmLiouvilleEigenfunction V eigval v) :
    ∃ C : ℝ, ∀ x, wronskian u v x = C := by
  -- By definition of $IsSturmLi ouvilleEigenfunction$, we know that $u$ and $ v$ satisfy the eigenvalue equation and are differentiable up to the second derivative.
  obtain ⟨hu_diff, hu_eigen, hu_mem⟩ := hu
  obtain ⟨hv_diff, hv_eigen, hv_mem⟩ := hv;
  -- The derivative of the Wronskian is zero, so the Wronskian is constant.
  have h_deriv_zero : ∀ x, deriv (fun x => wronskian u v x) x = 0 := by
    intro x; unfold wronskian; norm_num [ hu_diff.differentiableAt, hu_eigen.differentiableAt, hv_diff.differentiableAt, hv_eigen.differentiableAt ] ; ring;
    cases lt_or_ge ( u x ) 0 <;> cases lt_or_ge ( v x ) 0 <;> nlinarith [ hu_mem.1 x, hv_mem.1 x ];
  use wronskian u v 0;
  intro x; exact is_const_of_deriv_eq_zero ( fun x => DifferentiableAt.sub ( DifferentiableAt.mul ( hu_diff.differentiableAt ) ( hv_eigen.differentiableAt ) ) ( DifferentiableAt.mul ( hv_diff.differentiableAt ) ( hu_eigen.differentiableAt ) ) ) h_deriv_zero x 0;

lemma exists_seq_tendsto_zero_of_memLp {f : ℝ → ℝ} (hf : MeasureTheory.MemLp f 2 MeasureTheory.volume) :
    ∃ s : ℕ → ℝ, Filter.Tendsto s Filter.atTop Filter.atTop ∧ Filter.Tendsto (f ∘ s) Filter.atTop (nhds 0) := by
  -- Fix an arbitrary $n \in \mathbb{N}$.
  have h_fixed_n : ∀ n : ℕ, ∃ x : ℝ, x > n ∧ |f x| < 1 / (n + 1) := by
    intro n
    by_contra h_contra
    push Not at h_contra
    have h_integral : ∫⁻ x in Set.Ioi (n : ℝ), ENNReal.ofReal (|f x|^2) = ⊤ := by
      have h_integral : ∫⁻ x in Set.Ioi (n : ℝ), ENNReal.ofReal (|f x|^2) ≥ ∫⁻ x in Set.Ioi (n : ℝ), ENNReal.ofReal ((1 / (n + 1))^2) := by
        refine' MeasureTheory.setLIntegral_mono' measurableSet_Ioi fun x hx => ENNReal.ofReal_le_ofReal <| pow_le_pow_left₀ ( by positivity ) ( h_contra x hx ) 2;
      exact le_top.antisymm ( h_integral.trans' ( by simp +decide [ ENNReal.ofReal_pos, Nat.cast_add_one_ne_zero ] ) );
    convert h_integral.not_lt <| lt_of_le_of_lt ( MeasureTheory.setLIntegral_le_lintegral _ _ ) _;
    convert hf.integrable_sq.lintegral_lt_top using 1 ; norm_num [ sq_abs ];
  choose s hs using h_fixed_n;
  exact ⟨ s, Filter.tendsto_atTop_mono ( fun n => le_of_lt ( hs n |>.1 ) ) tendsto_natCast_atTop_atTop, squeeze_zero_norm ( fun n => le_of_lt ( hs n |>.2 ) ) ( tendsto_one_div_add_atTop_nhds_zero_nat ) ⟩

lemma not_memLp_of_tendsto_deriv_pos {u : ℝ → ℝ} (hu : Differentiable ℝ u)
    {L : ℝ} (hL : 0 < L) (h_tendsto : Filter.Tendsto (deriv u) Filter.atTop (nhds L)) :
    ¬ MeasureTheory.MemLp u 2 MeasureTheory.volume := by
  -- If $u' \to L > 0$, then there exists some $x_0$ such that for all $x > x_0$, $u'(x) > L/2$.
  obtain ⟨x₀, hx₀⟩ : ∃ x₀, ∀ x > x₀, deriv u x > L / 2 := by
    exact Filter.eventually_atTop.mp ( h_tendsto.eventually ( lt_mem_nhds ( half_lt_self hL ) ) ) |> fun ⟨ x₀, hx₀ ⟩ => ⟨ x₀, fun x hx => hx₀ x hx.le ⟩;
  -- Then $u(x) > u(x₀) + L/2(x - x₀)$ for $x > x₀$.
  have h_bound : ∀ x > x₀, u x > u x₀ + L / 2 * (x - x₀) := by
    intro x hx;
    have := exists_deriv_eq_slope u hx;
    exact this ( hu.continuous.continuousOn ) ( hu.differentiableOn ) |> fun ⟨ c, hc₁, hc₂ ⟩ => by nlinarith [ hx₀ c hc₁.1, mul_div_cancel₀ ( u x - u x₀ ) ( sub_ne_zero_of_ne hx.ne' ) ] ;
  -- Since $u(x) > u(x₀) + L/2(x - x₀)$ for $x > x₀$, we can choose $x$ large enough such that $u(x) > 1$.
  obtain ⟨x₁, hx₁⟩ : ∃ x₁ > x₀, ∀ x > x₁, u x > 1 := by
    exact ⟨ x₀ + ⌈ ( 1 - u x₀ ) / ( L / 2 ) ⌉₊ + 1, by linarith, fun x hx => by nlinarith [ Nat.le_ceil ( ( 1 - u x₀ ) / ( L / 2 ) ), h_bound x ( by linarith ), mul_div_cancel₀ ( 1 - u x₀ ) ( by linarith : ( L / 2 ) ≠ 0 ) ] ⟩;
  -- Since $u(x) > 1$ for $x > x₁$, the integral of $u^2$ over $(x₁, \infty)$ is infinite.
  have h_integral_infinite : ¬MeasureTheory.IntegrableOn (fun x => u x ^ 2) (Set.Ioi x₁) := by
    have h_integral_infinite : ¬MeasureTheory.IntegrableOn (fun x => 1 : ℝ → ℝ) (Set.Ioi x₁) := by
      norm_num;
    refine fun h => h_integral_infinite <| h.mono' ?_ ?_;
    · exact Measurable.aestronglyMeasurable measurable_const;
    · filter_upwards [ MeasureTheory.ae_restrict_mem measurableSet_Ioi ] with x hx using by rw [ Real.norm_of_nonneg zero_le_one ] ; nlinarith [ hx₁.2 x hx ] ;
  contrapose! h_integral_infinite;
  exact MeasureTheory.Integrable.integrableOn ( by simpa using h_integral_infinite.integrable_sq )

lemma eventually_V_gt_eigenvalue (V : ℝ → ℝ) (eigval : ℝ)
    (hV : IsConfiningPotential V) :
    ∃ R, ∀ x ≥ R, V x > eigval + 1 := by
  have := hV.2.eventually_gt_atTop ( eigval + 1 ) ; aesop;

lemma not_memLp_of_zero_and_deriv_pos_and_confining {u : ℝ → ℝ} {V : ℝ → ℝ} {eigval x₀ : ℝ}
    (hu_diff : DifferentiableOn ℝ u (Set.Ici x₀))
    (hu_deriv_diff : DifferentiableOn ℝ (deriv u) (Set.Ici x₀))
    (h_eq : ∀ x ≥ x₀, deriv (deriv u) x = (V x - eigval) * u x)
    (hV : ∀ x ≥ x₀, V x > eigval)
    (h_zero : u x₀ = 0)
    (h_deriv_pos : deriv u x₀ > 0) :
    ¬ MeasureTheory.MemLp u 2 MeasureTheory.volume := by
      -- Since the derivative of $u$ is positive at $x₀$ and $u$ is not identically zero, the derivative must remain positive for all $x \geq x₀$.
      have h_deriv_pos_all : ∀ x ≥ x₀, deriv u x > 0 := by
        -- By contradiction, assume there exists some $x_1 \geq x₀$ such that $deriv u x_1 \leq 0$.
        by_contra h_contra;
        -- Let $x_1$ be the smallest point in $[x₀, \infty)$ where $deriv u x_1 \leq 0$.
        obtain ⟨x₁, hx₁_ge, hx₁_le⟩ : ∃ x₁ ≥ x₀, deriv u x₁ ≤ 0 ∧ ∀ x, x₀ ≤ x → x < x₁ → deriv u x > 0 := by
          use sInf { x | x₀ ≤ x ∧ deriv u x ≤ 0 };
          -- Since the set is non-empty and closed, the infimum must be in the set.
          have h_inf_in_set : InfSet.sInf {x | x₀ ≤ x ∧ deriv u x ≤ 0} ∈ {x | x₀ ≤ x ∧ deriv u x ≤ 0} := by
            apply_rules [ IsClosed.csInf_mem ];
            · have h_closed : ContinuousOn (deriv u) (Set.Ici x₀) := by
                exact hu_deriv_diff.continuousOn;
              exact h_closed.preimage_isClosed_of_isClosed isClosed_Ici isClosed_Iic;
            · exact by push Not at h_contra; exact h_contra;
            · exact ⟨ x₀, fun x hx => hx.1 ⟩;
          exact ⟨ h_inf_in_set.1, h_inf_in_set.2, fun x hx₁ hx₂ => not_le.1 fun hx₃ => not_le.mpr hx₂ <| csInf_le ⟨ x₀, fun x hx => hx.1 ⟩ ⟨ hx₁, hx₃ ⟩ ⟩;
        -- Since $u$ is differentiable and $u'(x₁) \leq 0$, we have $u(x₁) > 0$.
        have h_u_pos : u x₁ > 0 := by
          -- Apply the Mean Value Theorem to the interval [x₀, x₁].
          obtain ⟨c, hc⟩ : ∃ c ∈ Set.Ioo x₀ x₁, deriv u c = (u x₁ - u x₀) / (x₁ - x₀) := by
            apply_rules [ exists_deriv_eq_slope ];
            · exact hx₁_ge.lt_of_ne ( by rintro rfl; linarith );
            · exact hu_diff.continuousOn.mono ( Set.Icc_subset_Ici_self );
            · exact hu_diff.mono <| Set.Ioo_subset_Icc_self.trans <| Set.Icc_subset_Ici_self;
          have := hx₁_le.2 c hc.1.1.le hc.1.2; rw [ eq_div_iff ] at hc <;> nlinarith [ hc.1.1, hc.1.2 ] ;
        -- Since $u$ is differentiable and $u'(x₁) \leq 0$, we have $u''(x₁) > 0$.
        have h_u''_pos : deriv (deriv u) x₁ > 0 := by
          exact h_eq x₁ hx₁_ge ▸ mul_pos ( sub_pos.mpr ( hV x₁ hx₁_ge ) ) h_u_pos;
        -- Since $u$ is differentiable and $u'(x₁) \leq 0$, we have $u''(x₁) > 0$, which contradicts $u''(x₁) = (V(x₁) - \lambda)u(x₁)$.
        have h_contra : Filter.Tendsto (fun x => (deriv u x - deriv u x₁) / (x - x₁)) (nhdsWithin x₁ (Set.Iio x₁)) (nhds (deriv (deriv u) x₁)) := by
          have h_contra : HasDerivAt (deriv u) (deriv (deriv u) x₁) x₁ := by
            exact differentiableAt_of_deriv_ne_zero h_u''_pos.ne' |> DifferentiableAt.hasDerivAt;
          rw [ hasDerivAt_iff_tendsto_slope ] at h_contra;
          simpa [ slope_fun_def_field, div_eq_inv_mul ] using h_contra.mono_left ( nhdsWithin_mono _ <| by simp +decide );
        have := h_contra.eventually ( lt_mem_nhds h_u''_pos ) ; have := this.and ( Ioo_mem_nhdsLT <| show x₁ > x₀ from lt_of_le_of_ne hx₁_ge <| Ne.symm <| by rintro rfl; linarith ) ; obtain ⟨ x, hx₁, hx₂ ⟩ := this.exists; rw [ div_eq_mul_inv ] at hx₁; nlinarith [ hx₁_le.2 x hx₂.1.le hx₂.2, inv_mul_cancel₀ ( by linarith : ( x - x₁ ) ≠ 0 ) ] ;
      -- Since the derivative of $u$ is positive for all $x \geq x₀$, $u$ is strictly increasing on $[x₀, \infty)$.
      have h_inc : StrictMonoOn u (Set.Ici x₀) := by
        -- Apply the theorem that states if the derivative of a function is positive on an interval, then the function is strictly increasing on that interval.
        apply strictMonoOn_of_deriv_pos;
        · exact convex_Ici x₀;
        · exact hu_diff.continuousOn;
        · exact fun x hx => h_deriv_pos_all x <| interior_subset hx |> fun hx' => by simpa using hx';
      -- Since $u$ is strictly increasing and $u(x₀) = 0$, we have $u(x) > 0$ for all $x > x₀$.
      have h_pos : ∀ x > x₀, u x > 0 := by
        exact fun x hx => h_zero ▸ h_inc ( show x₀ ∈ Set.Ici x₀ by norm_num ) ( show x ∈ Set.Ici x₀ by exact hx.le ) hx;
      -- Since $u$ is strictly increasing and $u(x₀) = 0$, we have $u(x) \geq u(x₀ + 1)$ for all $x \geq x₀ + 1$.
      have h_bound : ∀ x ≥ x₀ + 1, u x ≥ u (x₀ + 1) := by
        exact fun x hx => h_inc.le_iff_le ( by norm_num ) ( by norm_num; linarith ) |>.2 hx;
      -- Since $u(x) \geq u(x₀ + 1)$ for all $x \geq x₀ + 1$, we have $\int_{x₀ + 1}^{\infty} u(x)^2 \, dx \geq \int_{x₀ + 1}^{\infty} u(x₀ + 1)^2 \, dx$.
      have h_integral_bound : ¬ MeasureTheory.IntegrableOn (fun x => u x ^ 2) (Set.Ici (x₀ + 1)) := by
        have h_integral_bound : ¬ MeasureTheory.IntegrableOn (fun x => u (x₀ + 1) ^ 2) (Set.Ici (x₀ + 1)) := by
          simp +zetaDelta at *;
          linarith [ h_pos ( x₀ + 1 ) ( by linarith ) ];
        refine fun h => h_integral_bound <| h.mono' ?_ ?_;
        · fun_prop;
        · filter_upwards [ MeasureTheory.ae_restrict_mem measurableSet_Ici ] with x hx using by rw [ Real.norm_of_nonneg ( sq_nonneg _ ) ] ; exact pow_le_pow_left₀ ( le_of_lt ( h_pos _ ( by linarith [ Set.mem_Ici.mp hx ] ) ) ) ( h_bound _ hx ) 2;
      contrapose! h_integral_bound;
      exact MeasureTheory.Integrable.integrableOn ( by exact MeasureTheory.MemLp.integrable_sq h_integral_bound )

lemma constant_sign_of_no_zeros {u : ℝ → ℝ} {R : ℝ}
    (hu_cont : ContinuousOn u (Set.Ici R))
    (h_no_zero : ∀ x ≥ R, u x ≠ 0) :
    (∀ x ≥ R, u x > 0) ∨ (∀ x ≥ R, u x < 0) := by
  contrapose! h_no_zero;
  -- By the Intermediate Value Theorem, since $u$ is continuous on $[R, \infty)$ and $u(x)$ changes sign, there must be some $c \in [R, \infty)$ such that $u(c) = 0$.
  have h_ivt : IsConnected (u '' Set.Ici R) := by
    exact ⟨ Set.Nonempty.image _ ⟨ R, Set.self_mem_Ici ⟩, isPreconnected_Ici.image _ hu_cont ⟩;
  exact h_ivt.Icc_subset ( Set.mem_image_of_mem u h_no_zero.1.choose_spec.1 ) ( Set.mem_image_of_mem u h_no_zero.2.choose_spec.1 ) ⟨ h_no_zero.1.choose_spec.2, h_no_zero.2.choose_spec.2 ⟩

lemma tendsto_deriv_zero_of_convex_nonneg_l2 (u : ℝ → ℝ)
    (hu_diff : Differentiable ℝ u)
    (hu_deriv_diff : Differentiable ℝ (deriv u))
    (hu_l2 : MeasureTheory.MemLp u 2 MeasureTheory.volume)
    (h_pos : ∀ᶠ x in Filter.atTop, u x ≥ 0)
    (h_convex : ∀ᶠ x in Filter.atTop, deriv (deriv u) x ≥ 0) :
    Filter.Tendsto (deriv u) Filter.atTop (nhds 0) := by
      contrapose! hu_l2;
      -- If the derivative of $u$ is positive and bounded below by some positive constant, then $u$ would grow without bound, contradicting it being in $L^2$.
      by_cases h_deriv_pos : ∃ L > 0, ∀ᶠ x in Filter.atTop, deriv u x ≥ L;
      · obtain ⟨ L, hL_pos, hL ⟩ := h_deriv_pos;
        -- If the derivative of $u$ is positive and bounded below by some positive constant, then $u$ would grow without bound, contradicting it being in $L^2$. Hence, the derivative must tend to zero.
        have h_unbounded : ∀ᶠ x in Filter.atTop, u x ≥ u (Classical.choose (Filter.eventually_atTop.mp hL)) + L * (x - Classical.choose (Filter.eventually_atTop.mp hL)) := by
          have h_unbounded : ∀ x ≥ Classical.choose (Filter.eventually_atTop.mp hL), u x ≥ u (Classical.choose (Filter.eventually_atTop.mp hL)) + L * (x - Classical.choose (Filter.eventually_atTop.mp hL)) := by
            intro x hx;
            by_cases hx_eq : x = Classical.choose (Filter.eventually_atTop.mp hL);
            · aesop;
            · have := exists_deriv_eq_slope u ( lt_of_le_of_ne hx ( Ne.symm hx_eq ) );
              exact this ( hu_diff.continuous.continuousOn ) ( hu_diff.differentiableOn ) |> fun ⟨ c, hc₁, hc₂ ⟩ => by nlinarith [ hc₁.1, hc₁.2, mul_div_cancel₀ ( u x - u ( Classical.choose ( Filter.eventually_atTop.mp hL ) ) ) ( sub_ne_zero_of_ne hx_eq ), Classical.choose_spec ( Filter.eventually_atTop.mp hL ) c hc₁.1.le ] ;
          exact Filter.eventually_atTop.mpr ⟨ _, h_unbounded ⟩;
        have h_unbounded : Filter.Tendsto u Filter.atTop Filter.atTop := by
          refine' Filter.tendsto_atTop_mono' _ _ _;
          exacts [ fun x => u ( Classical.choose ( Filter.eventually_atTop.mp hL ) ) + L * ( x - Classical.choose ( Filter.eventually_atTop.mp hL ) ), h_unbounded, Filter.tendsto_atTop_add_const_left _ _ <| Filter.Tendsto.const_mul_atTop hL_pos <| Filter.tendsto_id.atTop_add tendsto_const_nhds ];
        intro H;
        have : MeasureTheory.eLpNorm u 2 MeasureTheory.volume < ⊤ := H;
        rw [ MeasureTheory.eLpNorm_eq_lintegral_rpow_enorm_toReal ] at this;
        · -- Since $u$ tends to infinity, there exists some $R$ such that for all $x \geq R$, $|u(x)| \geq 1$.
          obtain ⟨R, hR⟩ : ∃ R, ∀ x ≥ R, |u x| ≥ 1 := by
            exact Filter.eventually_atTop.mp ( h_unbounded.eventually_ge_atTop 1 ) |> fun ⟨ R, hR ⟩ => ⟨ R, fun x hx => by linarith [ hR x hx, le_abs_self ( u x ) ] ⟩;
          -- Since $|u(x)| \geq 1$ for all $x \geq R$, we have $\int_{R}^{\infty} |u(x)|^2 \, dx \geq \int_{R}^{\infty} 1 \, dx = \infty$.
          have h_integral_infinite : ∫⁻ x in Set.Ici R, ‖u x‖ₑ ^ 2 ≥ ∫⁻ x in Set.Ici R, 1 := by
            refine' MeasureTheory.setLIntegral_mono' measurableSet_Ici fun x hx => _;
            exact one_le_pow₀ ( by simpa [ Real.enorm_eq_ofReal_abs ] using hR x hx );
          simp_all +decide [ ENNReal.toReal_ofNat ];
          exact h_integral_infinite.not_lt <| lt_of_le_of_lt ( MeasureTheory.setLIntegral_le_lintegral _ _ ) <| lt_top_iff_ne_top.mpr <| by aesop;
        · norm_num;
        · norm_num;
        · exact H.aestronglyMeasurable;
      · -- If the derivative of $u$ is negative and bounded above by some negative constant, then $u$ would decrease without bound, contradicting it being in $L^2$.
        by_cases h_deriv_neg : ∃ L < 0, ∀ᶠ x in Filter.atTop, deriv u x ≤ L;
        · obtain ⟨ L, hL_neg, hL ⟩ := h_deriv_neg;
          have h_decreasing : ∀ᶠ x in Filter.atTop, u x ≤ u (Classical.choose (Filter.eventually_atTop.mp hL)) + L * (x - Classical.choose (Filter.eventually_atTop.mp hL)) := by
            have := Classical.choose_spec ( Filter.eventually_atTop.mp hL );
            filter_upwards [ Filter.eventually_ge_atTop ( Classical.choose ( Filter.eventually_atTop.mp hL ) ) ] with x hx;
            by_cases hx_eq : x = Classical.choose (Filter.eventually_atTop.mp hL);
            · aesop;
            · have := exists_deriv_eq_slope u ( lt_of_le_of_ne hx ( Ne.symm hx_eq ) );
              exact this ( hu_diff.continuous.continuousOn ) ( hu_diff.differentiableOn ) |> fun ⟨ c, hc₁, hc₂ ⟩ => by nlinarith [ ‹∀ b ≥ Classical.choose ( Filter.eventually_atTop.mp hL ), deriv u b ≤ L› c hc₁.1.le, mul_div_cancel₀ ( u x - u ( Classical.choose ( Filter.eventually_atTop.mp hL ) ) ) ( sub_ne_zero_of_ne hx_eq ) ] ;
          have h_decreasing : ∀ᶠ x in Filter.atTop, u x ≤ -1 := by
            filter_upwards [ h_decreasing, Filter.eventually_gt_atTop ( Classical.choose ( Filter.eventually_atTop.mp hL ) + ( |u ( Classical.choose ( Filter.eventually_atTop.mp hL ) )| + 1 ) / ( -L ) ) ] with x hx₁ hx₂ using by cases abs_cases ( u ( Classical.choose ( Filter.eventually_atTop.mp hL ) ) ) <;> nlinarith [ mul_div_cancel₀ ( |u ( Classical.choose ( Filter.eventually_atTop.mp hL ) )| + 1 ) ( by linarith : ( -L ) ≠ 0 ) ] ;
          exact absurd ( h_decreasing.and h_pos ) fun h => by obtain ⟨ x, hx₁, hx₂ ⟩ := h.exists; linarith;
        · -- Since the derivative is non-decreasing and bounded below by some negative constant, it must converge to some limit $L$.
          obtain ⟨L, hL⟩ : ∃ L, Filter.Tendsto (deriv u) Filter.atTop (nhds L) := by
            have h_monotone : MonotoneOn (deriv u) (Set.Ici (Classical.choose (Filter.eventually_atTop.mp h_convex))) := by
              intros x hx y hy hxy;
              by_cases hxy_eq : x = y;
              · rw [ hxy_eq ];
              · have := exists_deriv_eq_slope ( deriv u ) ( lt_of_le_of_ne hxy hxy_eq );
                exact this ( hu_deriv_diff.continuous.continuousOn ) ( hu_deriv_diff.differentiableOn ) |> fun ⟨ c, hc₁, hc₂ ⟩ => by nlinarith [ hc₁.1, hc₁.2, mul_div_cancel₀ ( deriv u y - deriv u x ) ( sub_ne_zero_of_ne <| Ne.symm hxy_eq ), Classical.choose_spec ( Filter.eventually_atTop.mp h_convex ) c <| by linarith [ hc₁.1, hc₁.2, hx.out, hy.out ] ] ;
            have h_bounded : BddAbove (Set.image (deriv u) (Set.Ici (Classical.choose (Filter.eventually_atTop.mp h_convex)))) := by
              simp +zetaDelta at *;
              exact ⟨ 1, Set.forall_mem_image.2 fun x hx => le_of_not_gt fun hx' => by obtain ⟨ y, hy₁, hy₂ ⟩ := h_deriv_pos 1 zero_lt_one x; linarith [ h_monotone hx ( show y ∈ Set.Ici ( Classical.choose ( Filter.eventually_atTop.mp h_convex ) ) from by exact le_trans hx hy₁ ) hy₁ ] ⟩;
            have h_converge : Filter.Tendsto (deriv u) Filter.atTop (nhds (sSup (Set.image (deriv u) (Set.Ici (Classical.choose (Filter.eventually_atTop.mp h_convex)))))) := by
              apply_rules [ tendsto_order.2 ⟨ _, _ ⟩ ];
              · exact fun x hx => by rcases exists_lt_of_lt_csSup ( Set.Nonempty.image _ <| Set.nonempty_Ici ) hx with ⟨ y, ⟨ z, hz, rfl ⟩, hy ⟩ ; filter_upwards [ Filter.eventually_ge_atTop z ] with w hw using hy.trans_le <| h_monotone hz ( show w ∈ Set.Ici ( Classical.choose ( Filter.eventually_atTop.mp h_convex ) ) from hw.trans' hz ) hw;
              · exact fun x hx => Filter.eventually_atTop.mpr ⟨ Classical.choose ( Filter.eventually_atTop.mp h_convex ), fun y hy => lt_of_le_of_lt ( le_csSup h_bounded <| Set.mem_image_of_mem _ hy ) hx ⟩;
            exact ⟨ _, h_converge ⟩;
          by_cases hL_zero : L = 0;
          · aesop;
          · -- Since $L \neq 0$, we have $L > 0$ or $L < 0$.
            by_cases hL_pos : 0 < L;
            · exact False.elim <| h_deriv_pos ⟨ L / 2, half_pos hL_pos, by filter_upwards [ hL.eventually ( lt_mem_nhds <| half_lt_self hL_pos ) ] with x hx using by linarith ⟩;
            · exact False.elim <| h_deriv_neg ⟨ L / 2, by linarith [ show L < 0 from lt_of_le_of_ne ( le_of_not_gt hL_pos ) hL_zero ], by filter_upwards [ hL.eventually ( gt_mem_nhds <| show L < L / 2 by linarith [ show L < 0 from lt_of_le_of_ne ( le_of_not_gt hL_pos ) hL_zero ] ) ] with x hx using by linarith ⟩

lemma tendsto_zero_of_convex_nonneg_l2_and_deriv (u : ℝ → ℝ)
    (hu_diff : Differentiable ℝ u)
    (hu_deriv_diff : Differentiable ℝ (deriv u))
    (hu_l2 : MeasureTheory.MemLp u 2 MeasureTheory.volume)
    (h_pos : ∀ᶠ x in Filter.atTop, u x ≥ 0)
    (h_convex : ∀ᶠ x in Filter.atTop, deriv (deriv u) x ≥ 0) :
    Filter.Tendsto u Filter.atTop (nhds 0) ∧ Filter.Tendsto (deriv u) Filter.atTop (nhds 0) := by
      constructor;
      · -- Since $u$ is convex and non-negative for large $x$, and $u$ tends to zero as $x$ tends to infinity, $u$ must be decreasing for large $x$.
        have h_decreasing : ∃ R, ∀ x ≥ R, deriv u x ≤ 0 := by
          have h_deriv_zero : Filter.Tendsto (deriv u) Filter.atTop (nhds 0) := by
            apply_rules [ tendsto_deriv_zero_of_convex_nonneg_l2 ];
          have h_deriv_zero : ∀ᶠ x in Filter.atTop, deriv (deriv u) x ≥ 0 := by
            exact h_convex;
          obtain ⟨ R, hR ⟩ := Filter.eventually_atTop.mp h_deriv_zero;
          have h_deriv_nonneg : ∀ x ≥ R, deriv u x ≤ 0 := by
            intro x hx
            have h_lim : Filter.Tendsto (deriv u) Filter.atTop (nhds 0) := by
              assumption
            have h_deriv_nonneg : ∀ y ≥ x, deriv u y ≥ deriv u x := by
              -- Since the second derivative is non-negative on [R, ∞), the first derivative is non-decreasing on [R, ∞).
              have h_deriv_nonneg : ∀ y ≥ x, deriv u y ≥ deriv u x := by
                intro y hy
                have h_mean_val : ∀ a b, R ≤ a → a < b → ∃ c ∈ Set.Ioo a b, deriv (deriv u) c = (deriv u b - deriv u a) / (b - a) := by
                  intros a b ha hb; exact (by
                  have := exists_deriv_eq_slope ( deriv u ) hb;
                  exact this ( hu_deriv_diff.continuous.continuousOn ) ( hu_deriv_diff.differentiableOn ))
                cases eq_or_lt_of_le hy <;> [ aesop; obtain ⟨ c, ⟨ hxc, hcy ⟩, hcd ⟩ := h_mean_val x y hx ‹_› <;> nlinarith [ hR c ( by linarith ), mul_div_cancel₀ ( deriv u y - deriv u x ) ( sub_ne_zero_of_ne <| by linarith : ( y - x ) ≠ 0 ) ] ];
              assumption
            exact le_of_tendsto_of_tendsto tendsto_const_nhds h_lim ( Filter.eventually_atTop.mpr ⟨ x, h_deriv_nonneg ⟩ );
          use R;
        -- Since $u$ is decreasing and non-negative for large $x$, it must converge to some limit $L$ as $x$ tends to infinity.
        obtain ⟨R, hR⟩ : ∃ R, ∀ x ≥ R, deriv u x ≤ 0 := h_decreasing
        have h_lim : Filter.Tendsto u Filter.atTop (nhds (sInf {u x | x ≥ R})) := by
          have h_decreasing : AntitoneOn u (Set.Ici R) := by
            -- By the Mean Value Theorem, if the derivative of a function is non-positive on an interval, then the function is antitone on that interval.
            have h_mvt : ∀ x y : ℝ, R ≤ x → x < y → ∃ c ∈ Set.Ioo x y, deriv u c = (u y - u x) / (y - x) := by
              -- Apply the Mean Value Theorem to the interval [x, y].
              intros x y hx hy; exact exists_deriv_eq_slope u hy (hu_diff.continuous.continuousOn) (hu_diff.differentiableOn)
            generalize_proofs at *; (
            exact antitoneOn_iff_forall_lt.mpr fun x hx y hy hxy => by obtain ⟨ c, ⟨ hxc, hcy ⟩, hcd ⟩ := h_mvt x y hx hxy; have := hR c ( by linarith [ Set.mem_Ici.mp hx, Set.mem_Ici.mp hy ] ) ; rw [ hcd, div_le_iff₀ ] at this <;> linarith;);
          refine' ( tendsto_order.2 ⟨ fun x hx => _, fun x hx => _ ⟩ );
          · filter_upwards [ Filter.eventually_ge_atTop R ] with y hy using hx.trans_le <| csInf_le ⟨ 0, by rintro x ⟨ z, hz, rfl ⟩ ; exact h_pos.and ( Filter.eventually_ge_atTop z ) |> fun h => h.exists.elim fun w hw => hw.1.trans <| h_decreasing ( show R ≤ z by linarith ) ( show R ≤ w by linarith ) <| by linarith ⟩ ⟨ y, hy, rfl ⟩;
          · rcases exists_lt_of_csInf_lt ( by exact ⟨ _, ⟨ R, le_rfl, rfl ⟩ ⟩ ) hx with ⟨ y, ⟨ z, hz, rfl ⟩, hy ⟩ ; filter_upwards [ Filter.eventually_ge_atTop z ] with w hw using lt_of_le_of_lt ( h_decreasing ( show R ≤ z by linarith ) ( show R ≤ w by linarith ) hw ) hy;
        have := exists_seq_tendsto_zero_of_memLp hu_l2;
        obtain ⟨ s, hs₁, hs₂ ⟩ := this; have := tendsto_nhds_unique hs₂ ( h_lim.comp hs₁ ) ; aesop;
      · apply_rules [ tendsto_deriv_zero_of_convex_nonneg_l2 ]

lemma is_eigenfunction_neg {V : ℝ → ℝ} {eigval : ℝ} {u : ℝ → ℝ}
    (hu : IsSturmLiouvilleEigenfunction V eigval u) :
    IsSturmLiouvilleEigenfunction V eigval (-u) := by
      refine' ⟨ _, _, _, _, _ ⟩;
      · exact hu.1.neg;
      · convert hu.2.1.neg using 1 ; aesop;
      · intro x;
        rw [ show deriv ( -u ) = fun x => -deriv u x from funext fun x => deriv.neg ] ; norm_num ; linarith [ hu.2.2.1 x ];
      · exact neg_ne_zero.mpr hu.2.2.2.1;
      · exact hu.2.2.2.2.neg

lemma zero_of_ode_zero_init {u P : ℝ → ℝ} {x₀ : ℝ}
    (hu_diff : Differentiable ℝ u)
    (hu_deriv_diff : Differentiable ℝ (deriv u))
    (hP_cont : Continuous P)
    (h_eq : ∀ x, deriv (deriv u) x = P x * u x)
    (h_u_zero : u x₀ = 0)
    (h_deriv_zero : deriv u x₀ = 0) :
    ∀ x, u x = 0 := by
  -- Let $F(x) = (u(x))^2 + (u'(x))^2$. Since $F(x₀) = 0$ and $F'(x) = 2(u(x)u'(x) + u'(x)u''(x)) = 2u'(x)(u(x) + Pu(x)) = 2u'(x)(1 + P)u(x)$, it follows that $F(x)$ is constant.
  set F : ℝ → ℝ := fun x => (u x)^2 + (deriv u x)^2
  have hF_deriv_zero : ∀ x, deriv F x = 2 * deriv u x * (1 + P x) * u x := by
    intro x; rw [ show F = fun x => u x ^ 2 + deriv u x ^ 2 from rfl ] ; norm_num [ hu_diff.differentiableAt, hu_deriv_diff.differentiableAt, h_eq ] ; ring;
  -- By Grönwall's inequality, since $|F'(x)| \leq 2|1 + P(x)|F(x)$ and $F(x₀) = 0$, we have $F(x) = 0$ for all $x$.
  have hF_zero : ∀ x, F x = 0 := by
    -- Since $|F'(x)| \leq 2|1 + P(x)|F(x)$ and $F(x₀) = 0$, we can apply Grönwall's inequality to conclude that $F(x) = 0$ for all $x$.
    have hF_zero : ∀ x, deriv (fun x => Real.exp (-2 * (∫ t in x₀..x, |1 + P t|)) * F x) x ≤ 0 := by
      intro x;
      by_cases hx : DifferentiableAt ℝ ( fun x => Real.exp ( -2 * ∫ t in x₀..x, |1 + P t| ) ) x <;> by_cases hx' : DifferentiableAt ℝ F x <;> simp_all +decide [ mul_assoc, mul_comm, mul_left_comm, Real.differentiableAt_exp, hu_diff.differentiableAt, hu_deriv_diff.differentiableAt ];
      · -- Apply the chain rule to compute the derivative of the exponential term.
        have h_exp_deriv : deriv (fun x => Real.exp (-(2 * ∫ t in x₀..x, |1 + P t|))) x = -2 * |1 + P x| * Real.exp (-(2 * ∫ t in x₀..x, |1 + P t|)) := by
          convert HasDerivAt.deriv ( HasDerivAt.exp ( HasDerivAt.neg ( HasDerivAt.const_mul 2 ( hasDerivAt_deriv_iff.mpr _ ) ) ) ) using 1;
          · rw [ show deriv ( fun x => ∫ t in x₀..x, |1 + P t| ) x = |1 + P x| from by apply_rules [ Continuous.deriv_integral ] ; continuity ] ; ring!;
          · have := DifferentiableAt.log hx;
            simpa using this ( by positivity ) |> DifferentiableAt.neg |> DifferentiableAt.div_const <| 2;
        cases abs_cases ( 1 + P x ) <;> nlinarith [ sq_nonneg ( u x - deriv u x ), sq_nonneg ( u x + deriv u x ), Real.exp_pos ( - ( 2 * ∫ t in x₀..x, |1 + P t| ) ), mul_le_mul_of_nonneg_right ( sq_nonneg ( u x - deriv u x ) ) ( Real.exp_nonneg ( - ( 2 * ∫ t in x₀..x, |1 + P t| ) ) ), mul_le_mul_of_nonneg_right ( sq_nonneg ( u x + deriv u x ) ) ( Real.exp_nonneg ( - ( 2 * ∫ t in x₀..x, |1 + P t| ) ) ) ];
      · exact False.elim <| hx' <| DifferentiableAt.add ( hu_diff.differentiableAt.pow 2 ) ( hu_deriv_diff.differentiableAt.pow 2 );
      · contrapose! hx;
        refine' DifferentiableAt.exp _;
        refine' DifferentiableAt.neg ( DifferentiableAt.mul ( differentiableAt_const _ ) _ );
        -- The integral of a continuous function is differentiable.
        have h_int_diff : ∀ x, HasDerivAt (fun x => ∫ t in x₀..x, |1 + P t|) (|1 + P x|) x := by
          intro x; apply_rules [ intervalIntegral.integral_hasDerivAt_right ];
          · exact Continuous.intervalIntegrable ( by continuity ) _ _;
          · exact Continuous.stronglyMeasurable ( by continuity ) |> fun h => h.stronglyMeasurableAtFilter;
          · exact ContinuousAt.abs ( continuousAt_const.add ( hP_cont.continuousAt ) );
        exact HasDerivAt.differentiableAt ( h_int_diff x );
      · contrapose! hx';
        exact DifferentiableAt.add ( hu_diff.differentiableAt.pow 2 ) ( hu_deriv_diff.differentiableAt.pow 2 );
    -- By Grönwall's inequality, since $|F'(x)| \leq 2|1 + P(x)|F(x)$ and $F(x₀) = 0$, we have $F(x) \leq 0$ for all $x$.
    have hF_nonpos : ∀ x, x ≥ x₀ → F x ≤ 0 := by
      -- Apply the mean value theorem to the interval $[x₀, x]$.
      intros x hx
      by_contra h_nonzero
      have h_mvt : ∃ c ∈ Set.Ioo x₀ x, deriv (fun x => Real.exp (-2 * (∫ t in x₀..x, |1 + P t|)) * F x) c = (Real.exp (-2 * (∫ t in x₀..x, |1 + P t|)) * F x - Real.exp (-2 * (∫ t in x₀..x₀, |1 + P t|)) * F x₀) / (x - x₀) := by
        apply_rules [ exists_deriv_eq_slope ];
        · exact hx.lt_of_ne ( by rintro rfl; aesop );
        · exact ContinuousOn.mul ( ContinuousOn.rexp <| ContinuousOn.mul continuousOn_const <| by exact Continuous.continuousOn <| by refine' intervalIntegral.continuous_primitive _ _ ; intros t ht ; exact Continuous.intervalIntegrable ( by continuity ) _ _ ) <| ContinuousOn.add ( hu_diff.continuous.continuousOn.pow 2 ) <| hu_deriv_diff.continuous.continuousOn.pow 2;
        · refine' DifferentiableOn.mul ( DifferentiableOn.exp ( DifferentiableOn.mul ( differentiableOn_const _ ) _ ) ) ( DifferentiableOn.add ( hu_diff.differentiableOn.pow 2 ) ( hu_deriv_diff.differentiableOn.pow 2 ) );
          intro x hx; exact (by
          refine' DifferentiableAt.differentiableWithinAt _;
          -- The integral of a continuous function is differentiable.
          have h_int_diff : ∀ x, HasDerivAt (fun x => ∫ t in x₀..x, |1 + P t|) (|1 + P x|) x := by
            intro x; apply_rules [ intervalIntegral.integral_hasDerivAt_right ];
            · exact Continuous.intervalIntegrable ( by continuity ) _ _;
            · exact Continuous.stronglyMeasurable ( by continuity ) |> fun h => h.stronglyMeasurableAtFilter;
            · exact ContinuousAt.abs ( continuousAt_const.add ( hP_cont.continuousAt ) );
          exact HasDerivAt.differentiableAt ( h_int_diff x ));
      simp +zetaDelta at *;
      obtain ⟨ c, ⟨ hc₁, hc₂ ⟩, hc ⟩ := h_mvt; have := hF_zero c; rw [ hc ] at this; rw [ div_le_iff₀ ] at this <;> nlinarith [ Real.exp_pos ( - ( 2 * ∫ t in x₀..x, |1 + P t| ) ) ] ;
    -- Similarly, by Grönwall's inequality, since $|F'(x)| \leq 2|1 + P(x)|F(x)$ and $F(x₀) = 0$, we have $F(x) \leq 0$ for all $x$.
    have hF_nonpos_neg : ∀ x, x ≤ x₀ → F x ≤ 0 := by
      have hF_nonpos_neg : ∀ x, x ≤ x₀ → deriv (fun x => Real.exp (2 * (∫ t in x₀..x, |1 + P t|)) * F x) x ≥ 0 := by
        intros x hx
        have hF_nonpos_neg : deriv (fun x => Real.exp (2 * (∫ t in x₀..x, |1 + P t|)) * F x) x = Real.exp (2 * (∫ t in x₀..x, |1 + P t|)) * (deriv F x + 2 * |1 + P x| * F x) := by
          convert HasDerivAt.deriv ( HasDerivAt.mul ( HasDerivAt.exp ( HasDerivAt.const_mul 2 <| hasDerivAt_deriv_iff.mpr _ ) ) <| hasDerivAt_deriv_iff.mpr _ ) using 1 <;> norm_num [ hu_diff.differentiableAt, hu_deriv_diff.differentiableAt, hF_deriv_zero ] ; ring;
          · rw [ show deriv ( fun x => ∫ t in x₀..x, |1 + P t| ) x = |1 + P x| from by apply_rules [ Continuous.deriv_integral ] ; continuity ] ; ring;
          · -- The integral of a continuous function is differentiable.
            have h_int_diff : ∀ x, HasDerivAt (fun x => ∫ t in x₀..x, |1 + P t|) (|1 + P x|) x := by
              intro x; apply_rules [ intervalIntegral.integral_hasDerivAt_right ];
              · exact Continuous.intervalIntegrable ( by continuity ) _ _;
              · exact Continuous.stronglyMeasurable ( by continuity ) |> fun h => h.stronglyMeasurableAtFilter;
              · exact ContinuousAt.abs ( continuousAt_const.add ( hP_cont.continuousAt ) );
            exact HasDerivAt.differentiableAt ( h_int_diff x );
          · exact DifferentiableAt.add ( hu_diff.differentiableAt.pow 2 ) ( hu_deriv_diff.differentiableAt.pow 2 );
        rw [hF_nonpos_neg];
        exact mul_nonneg ( Real.exp_nonneg _ ) ( by rw [ hF_deriv_zero ] ; cases abs_cases ( 1 + P x ) <;> nlinarith [ sq_nonneg ( deriv u x + u x ), sq_nonneg ( deriv u x - u x ) ] );
      intro x hx; by_contra h_neg; push Not at h_neg; (
      -- Apply the mean value theorem to the interval $[x, x₀]$.
      obtain ⟨c, hc⟩ : ∃ c ∈ Set.Ioo x x₀, deriv (fun x => Real.exp (2 * (∫ t in x₀..x, |1 + P t|)) * F x) c = (Real.exp (2 * (∫ t in x₀..x₀, |1 + P t|)) * F x₀ - Real.exp (2 * (∫ t in x₀..x, |1 + P t|)) * F x) / (x₀ - x) := by
        apply_rules [ exists_deriv_eq_slope ];
        · exact hx.lt_of_ne ( by rintro rfl; aesop );
        · refine' ContinuousOn.mul _ _;
          · fun_prop (disch := norm_num);
          · exact ContinuousOn.add ( hu_diff.continuous.continuousOn.pow 2 ) ( hu_deriv_diff.continuous.continuousOn.pow 2 );
        · refine' DifferentiableOn.mul ( DifferentiableOn.exp ( DifferentiableOn.mul ( differentiableOn_const _ ) _ ) ) ( DifferentiableOn.add ( hu_diff.differentiableOn.pow 2 ) ( hu_deriv_diff.differentiableOn.pow 2 ) );
          intro y hy; exact (by
          refine' DifferentiableAt.differentiableWithinAt _;
          have h_ftc : ∀ a b, HasDerivAt (fun x => ∫ t in a..x, |1 + P t|) (|1 + P b|) b := by
            intro a b; apply_rules [ intervalIntegral.integral_hasDerivAt_right ];
            · exact Continuous.intervalIntegrable ( by continuity ) _ _;
            · exact Continuous.stronglyMeasurable ( by continuity ) |> fun h => h.stronglyMeasurableAtFilter;
            · exact ContinuousAt.abs ( continuousAt_const.add ( hP_cont.continuousAt ) );
          exact HasDerivAt.differentiableAt ( h_ftc x₀ y ));
      simp +zetaDelta at *;
      rw [ eq_div_iff ] at hc <;> nlinarith [ hF_nonpos_neg c hc.1.2.le, Real.exp_pos ( 2 * ∫ t in x₀..x, |1 + P t| ), mul_pos ( Real.exp_pos ( 2 * ∫ t in x₀..x, |1 + P t| ) ) h_neg ]);
    exact fun x => le_antisymm ( if hx : x ≥ x₀ then hF_nonpos x hx else hF_nonpos_neg x ( le_of_not_ge hx ) ) ( by positivity );
  exact fun x => by norm_num [ show u x = 0 from by { have := hF_zero x; exact by { contrapose! this; positivity } } ] ;

lemma tendsto_zero_and_deriv_zero_of_eigenfunction {V : ℝ → ℝ} {eigval : ℝ} {u : ℝ → ℝ}
    (hV : IsConfiningPotential V)
    (hu : IsSturmLiouvilleEigenfunction V eigval u) :
    Filter.Tendsto u Filter.atTop (nhds 0) ∧ Filter.Tendsto (deriv u) Filter.atTop (nhds 0) := by
      -- By definition of IsSturmLiouvilleEigenfunction, we know that u is a solution to the differential equation.
      have h_eq : ∀ x, deriv (deriv u) x = (V x - eigval) * u x := by
        exact fun x => by linarith [ hu.2.2.1 x ] ;
      obtain ⟨R, hR⟩ : ∃ R, ∀ x ≥ R, V x > eigval + 1 := by
        exact eventually_V_gt_eigenvalue V eigval hV;
      by_cases h_sign : (∀ x ≥ R, u x ≥ 0) ∨ (∀ x ≥ R, u x ≤ 0);
      · cases' h_sign with h_sign h_sign <;> have := hu.2.2.2.2 <;> simp_all +decide [ MeasureTheory.memLp_one_iff_integrable ] ; (
        have := tendsto_zero_of_convex_nonneg_l2_and_deriv u hu.1 hu.2.1 this ( Filter.eventually_atTop.mpr ⟨ R, fun x hx => h_sign x hx ⟩ ) ( Filter.eventually_atTop.mpr ⟨ R, fun x hx => by nlinarith [ hR x hx, h_sign x hx, h_eq x ] ⟩ ) ; aesop;);
        have := tendsto_zero_of_convex_nonneg_l2_and_deriv ( -u ) ?_ ?_ ?_ ?_ ?_ <;> norm_num at *;
        exact ⟨ by simpa using this.1.neg, by simpa using this.2.neg ⟩;
        · exact hu.1;
        · exact hu.2.1;
        · exact this.neg;
        · exact ⟨ R, h_sign ⟩;
        · exact ⟨ R, fun x hx => by rw [ h_eq ] ; nlinarith [ hR x hx, h_sign x hx ] ⟩;
      · -- Since $u$ is not of one sign on $[R, \infty)$, there exists $x₀ \geq R$ such that $u(x₀) = 0$ and $u'(x₀) > 0$ or $u'(x₀) < 0$.
        obtain ⟨x₀, hx₀⟩ : ∃ x₀ ≥ R, u x₀ = 0 ∧ deriv u x₀ ≠ 0 := by
          -- Since $u$ is not of one sign on $[R, \infty)$, there exists $x₀ \geq R$ such that $u(x₀) = 0$.
          obtain ⟨x₀, hx₀⟩ : ∃ x₀ ≥ R, u x₀ = 0 := by
            push Not at h_sign;
            have h_ivt : IsConnected (Set.image u (Set.Ici R)) := by
              exact ⟨ Set.Nonempty.image _ ⟨ R, Set.self_mem_Ici ⟩, isPreconnected_Ici.image _ <| hu.1.continuous.continuousOn ⟩;
            exact h_ivt.Icc_subset ( Set.mem_image_of_mem u h_sign.1.choose_spec.1 ) ( Set.mem_image_of_mem u h_sign.2.choose_spec.1 ) ⟨ h_sign.1.choose_spec.2.le, h_sign.2.choose_spec.2.le ⟩;
          by_cases h_deriv_zero : deriv u x₀ = 0;
          · have h_zero : ∀ x, u x = 0 := by
              apply zero_of_ode_zero_init;
              exact hu.1;
              exact hu.2.1;
              exacts [ show Continuous fun x => V x - eigval from hV.1.sub continuous_const, fun x => h_eq x, hx₀.2, h_deriv_zero ];
            aesop;
          · exact ⟨ x₀, hx₀.1, hx₀.2, h_deriv_zero ⟩;
        cases lt_or_gt_of_ne hx₀.2.2 <;> simp_all +decide [ not_or ];
        · have h_contra : ¬ MeasureTheory.MemLp u 2 MeasureTheory.volume := by
            convert not_memLp_of_zero_and_deriv_pos_and_confining ( show DifferentiableOn ℝ ( fun x => -u x ) ( Set.Ici x₀ ) from ?_ ) ( show DifferentiableOn ℝ ( deriv ( fun x => -u x ) ) ( Set.Ici x₀ ) from ?_ ) ( fun x hx => ?_ ) ( fun x hx => ?_ ) ?_ ?_ using 1 <;> norm_num [ * ];
            any_goals exact fun x => V x - eigval + 1
            all_goals generalize_proofs at *;
            any_goals exact ( 1 : ℝ );
            · -- The L^2 norm of a function is the same as the L^2 norm of its negative.
              have h_norm_neg : ∀ f : ℝ → ℝ, MeasureTheory.MemLp f 2 MeasureTheory.MeasureSpace.volume ↔ MeasureTheory.MemLp (-f) 2 MeasureTheory.MeasureSpace.volume := by
                exact fun f => ⟨ fun hf => by simpa using hf.neg, fun hf => by simpa using hf.neg ⟩
              generalize_proofs at *; (
              exact h_norm_neg u);
            · exact hu.1.differentiableOn;
            · exact hu.2.1.differentiableOn.mono ( Set.Ici_subset_Ici.mpr le_rfl );
            · exact Or.inl <| by ring;
            · linarith [ hR x ( by linarith ) ];
          exact False.elim <| h_contra <| hu.2.2.2.2;
        · have h_not_memLp : ¬ MeasureTheory.MemLp u 2 MeasureTheory.volume := by
            apply not_memLp_of_zero_and_deriv_pos_and_confining;
            any_goals exact x₀;
            exact hu.1.differentiableOn;
            exact hu.2.1.differentiableOn;
            rotate_right;
            use fun x => V x - eigval + x₀;
            · aesop;
            · exact fun x hx => by linarith [ hR x ( by linarith ) ] ;
            · linarith;
            · linarith;
          exact False.elim <| h_not_memLp <| hu.2.2.2.2

theorem wronskian_zero_of_l2 (V : ℝ → ℝ) (eigval : ℝ)
    (hV : IsConfiningPotential V)
    (u v : ℝ → ℝ)
    (hu : IsSturmLiouvilleEigenfunction V eigval u)
    (hv : IsSturmLiouvilleEigenfunction V eigval v) :
    ∀ x, wronskian u v x = 0 := by
      -- By definition of $wronskian$, we know that $wronskian u v x = u x * deriv v x - v x * deriv u x$ for all $x$.
      have h_wronskian_def : ∃ C : ℝ, ∀ x, wronskian u v x = C := by
        -- Apply the lemma that states the Wronskian of two eigenfunctions with the same eigenvalue is constant.
        apply wronskian_constant_same_eigenvalue V eigval u v hu hv;
      -- Since $u$ and $v$ are eigenfunctions, their limits at infinity are zero. Therefore, the Wronskian at infinity must also be zero.
      have h_wronskian_zero_at_infty : Filter.Tendsto (fun x => wronskian u v x) Filter.atTop (nhds 0) := by
        -- Apply the lemma that states the limits of $u$ and $v$ at infinity are zero.
        have h_u_v_zero : Filter.Tendsto u Filter.atTop (nhds 0) ∧ Filter.Tendsto v Filter.atTop (nhds 0) ∧ Filter.Tendsto (deriv u) Filter.atTop (nhds 0) ∧ Filter.Tendsto (deriv v) Filter.atTop (nhds 0) := by
          exact ⟨ tendsto_zero_and_deriv_zero_of_eigenfunction hV hu |>.1, tendsto_zero_and_deriv_zero_of_eigenfunction hV hv |>.1, tendsto_zero_and_deriv_zero_of_eigenfunction hV hu |>.2, tendsto_zero_and_deriv_zero_of_eigenfunction hV hv |>.2 ⟩;
        simpa [ wronskian ] using Filter.Tendsto.sub ( h_u_v_zero.1.mul h_u_v_zero.2.2.2 ) ( h_u_v_zero.2.1.mul h_u_v_zero.2.2.1 );
      aesop

theorem linearly_dependent_of_wronskian_zero (V : ℝ → ℝ) (eigval : ℝ)
    (hV_cont : Continuous V)
    (u v : ℝ → ℝ)
    (hu : IsSturmLiouvilleEigenfunction V eigval u)
    (hv : IsSturmLiouvilleEigenfunction V eigval v)
    (hW : ∀ x, wronskian u v x = 0) :
    ∃ c : ℝ, ∀ x, v x = c * u x := by
      -- By definition of $IsSturmLiouvilleEigenfunction$, we know that $u$ and $v$ are solutions of the Sturm-Liouville equation.
      obtain ⟨hu_diff, hu_deriv_diff, hu_eq, hu_ne_zero, hu_memLp⟩ := hu
      obtain ⟨hv_diff, hv_deriv_diff, hv_eq, hv_ne_zero, hv_memLp⟩ := hv;
      -- Let $w(x) = v(x) - c u(x)$.
      obtain ⟨x₀, hx₀⟩ : ∃ x₀, u x₀ ≠ 0 := by
        exact Function.ne_iff.mp hu_ne_zero;
      -- Let $c = v(x₀) / u(x₀)$.
      set c : ℝ := v x₀ / u x₀;
      -- Let $w(x) = v(x) - c u(x)$. We need to show that $w(x) = 0$ for all $x$.
      set w : ℝ → ℝ := fun x => v x - c * u x;
      have hw_eq : ∀ x, deriv (deriv w) x = (V x - eigval) * w x := by
        intro x; rw [ show deriv w = fun x => deriv v x - deriv ( fun x => c * u x ) x from funext fun x => deriv_sub ( hv_diff.differentiableAt ) ( hu_diff.differentiableAt.const_mul _ ) ] ; norm_num [ hu_diff.differentiableAt, hu_deriv_diff.differentiableAt, hv_diff.differentiableAt, hv_deriv_diff.differentiableAt ] ; ring;
        linear_combination -hv_eq x + c * hu_eq x;
      have hw_zero : w x₀ = 0 ∧ deriv w x₀ = 0 := by
        simp +zetaDelta at *;
        norm_num [ hx₀, hu_diff.differentiableAt, hv_diff.differentiableAt ];
        simp_all +decide [ wronskian ];
        rw [ div_mul_eq_mul_div, sub_eq_zero, eq_div_iff hx₀ ] ; linarith [ hW x₀ ];
      have hw_zero_all : ∀ x, w x = 0 := by
        have hw_diff : Differentiable ℝ w := by
          exact Differentiable.sub hv_diff ( Differentiable.mul ( differentiable_const _ ) hu_diff )
        have hw_deriv_diff : Differentiable ℝ (deriv w) := by
          rw [ show deriv w = fun x => deriv v x - deriv ( fun x => c * u x ) x from funext fun x => deriv_sub ( hv_diff.differentiableAt ) ( hu_diff.differentiableAt.const_mul _ ) ] ; aesop
        apply zero_of_ode_zero_init hw_diff hw_deriv_diff ( show Continuous fun x => V x - eigval from hV_cont.sub continuous_const ) hw_eq hw_zero.1 hw_zero.2;
      exact ⟨ c, fun x => sub_eq_zero.mp ( hw_zero_all x ) ⟩

/-- An eigenvalue λ of the Sturm-Liouville operator with potential V
    is SIMPLE if every two eigenfunctions for λ are scalar multiples
    of each other — the eigenspace is one-dimensional. -/
def IsSimpleEigenvalue (V : ℝ → ℝ) (eigval : ℝ) : Prop :=
  ∀ u v : ℝ → ℝ,
    IsSturmLiouvilleEigenfunction V eigval u →
    IsSturmLiouvilleEigenfunction V eigval v →
    ∃ c : ℝ, ∀ x, v x = c * u x

/-- Capstone: every eigenvalue of a Sturm-Liouville operator with a confining potential is
simple.  Chain: confining → `wronskian_zero_of_l2` (W ≡ 0) →
`linearly_dependent_of_wronskian_zero` (v = c·u). -/
theorem sturm_liouville_simple_eigenvalues (V : ℝ → ℝ)
    (hV : IsConfiningPotential V) (eigval : ℝ) :
    IsSimpleEigenvalue V eigval := by
  intro u v hu hv
  have hW : ∀ x, wronskian u v x = 0 :=
    wronskian_zero_of_l2 V eigval hV u v hu hv
  exact linearly_dependent_of_wronskian_zero V eigval hV.1 u v hu hv hW

end

#print axioms sturm_liouville_simple_eigenvalues
#print axioms wronskian_zero_of_l2
#print axioms linearly_dependent_of_wronskian_zero
#print axioms zero_of_ode_zero_init
#print axioms tendsto_zero_and_deriv_zero_of_eigenfunction
#check sturm_liouville_simple_eigenvalues
